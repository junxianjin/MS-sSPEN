% ���ɶ�ά�ռ�����������
% by chenin 2013��6��17��16:58:59
clear all;close all;clc
addpath(strcat(pwd,'/produce2dSPENseq'));

%%
%-----------------------------------------
%==================ʱ���=================
%-----------------------------------------
date_now=datestr(now);
date_hour=num2str(hour(date_now));
date_minute=num2str(minute(date_now));
date_second=num2str(second(date_now));

ifsavedata = 1;
optimizeG = 1;
%%
%-----------------------------------------
%==================��������=================
%-----------------------------------------
param.filename='Spiral sampling';
param.sample='Various_ring_Spiral';
param.ExperimentMode='Simulation';
% param.ExperimentMode='Experiment';
param.gama=42.58e6;
sampts=round(106*64);    % sampling points
dt = 4e-6;
Ta = dt*sampts;
RO.Ta = Ta;
PE.Ta = Ta;

%-------------PE----------%
PE.L=45e-3;     % mm
PE.sw=64e3;     % Hz
PE.Te=4e-3;   % s
PE.Ge=PE.sw/(param.gama*PE.L);
PE.chirp=1; % 1����90�� 2����180��
PE.rd=0;  % �����
PE.ta=dt;
% PE.step=128;
%-------------RO----------%
RO.L=45e-3;     % mm
RO.sw=32e3;     % Hz
RO.Te=4e-3;   % s
RO.Ge=RO.sw/(param.gama*RO.L);
RO.chirp=2; % 1����90�� 2����180��
RO.rd=0;  % �����
RO.ta=dt;
% RO.step=128;


%%
%-----------------------------------------
%===============��Ʋ����켣==============
%-----------------------------------------

%----------------�Ƚ��ٻ������---------------%
% ECP=50*pi;	% each circle points
% dt=4e-06;   % �������
% t=0:dt:Ta;
% fs=1/dt;  % sampling rate
% f=fs/ECP;     % signal frequency 
% w=2*pi*f;
% 
% alpha=1;   %  alpha=0  ������    alpha=1 �Ƚ���
% r = w*t./sqrt(alpha+(1-alpha)*t+eps);
% theta = w*t./sqrt(alpha+(1-alpha)*t+eps);
% % theta = w.*t;
% C = r.*exp(1i*theta);



Nitlv_record=[20,30];   % [��С�����]
PE.demandpoint=6996;
PE.Gsam = 0;
cal_number = 2;    % ���������
if_calmin = 0;
while (abs(PE.demandpoint-length(PE.Gsam))~=0 && cal_number~=0)
%----------------���ܶ�---------------%

Nitlv = mean(Nitlv_record);
if  cal_number==1
    disp('---------------------------------------');
    disp('������������,����Ŀǰ���ŵ�Nitlv');
    disp('---------------------------------------');
    Nitlv = min(Nitlv_record);
end
radius = [0,0.5,0.7,1];  % normalized radius
fov = [1,1,0.4,0.01]; % supported field of view
dr = 1/1e4;
r = 0:dr:max(radius);
fov =  interp1(radius,fov,r,'linear');
dtheta = 2*pi*fov;
theta = cumsum(dtheta);
theta = theta/max(theta)*2*pi*Nitlv;
C = r.*exp(1i*theta);
plot(real(C),imag(C));
%-------------------------------------------------------------%
% �Թ켣���и�ֵ
% PE.Ge*PE.Te/2 = PE.C   90Chirp
% RO.Ge*RO.Te = RO.C    180Chirp
%-------------------------------------------------------------%
gama = 4.258;
PE.C = real(C)/max(abs(real(C)));
RO.C = imag(C)/max(abs(imag(C)));
PE.C = gama*PE.C*PE.Ge*PE.Te/2*1e5;   % ��һ��
RO.C = gama*RO.C*RO.Ge*RO.Te*1e5;
C = (PE.C + 1i*RO.C);

figure(1)
plot(C,'.');
title(['Point:',num2str(length(C)),' Equivalent Point:',num2str(round(sqrt(length(C)))),' Circle:',num2str(count_point(PE.C))]);  
axis([-max(abs(real(C)))*1.2 max(abs(real(C)))*1.2  -max(abs(imag(C)))*1.2  max(abs(imag(C)))*1.2])

%%
if optimizeG==1
%-------------------------------------
%===============Ӳ��Լ��==============
%-------------------------------------
Gmax = 25;  % Gauss ms cm
Smax = 180;

[C,time,g,s,k] = minTimeGradient(C, [], [], Gmax, Smax,4e-3,0);

PE.Gsam = real(g)/100;
RO.Gsam = imag(g)/100;
PE.Ga = max(abs(PE.Gsam));
RO.Ga = max(abs(RO.Gsam));
RO.Ta = RO.ta*length(RO.Gsam);
PE.Ta = PE.ta*length(PE.Gsam);
PE.Smax = Smax;
RO.Smax = Smax;

if PE.demandpoint>length(PE.Gsam)
    Nitlv_record(1) = Nitlv;
    if_calmin = 1;
    PE_backup=PE;
    RO_backup=RO;
else
    Nitlv_record(2) = Nitlv;
end

cal_number = cal_number-1;


disp('---------------------------------------');
disp('The current Nitlv_record');
disp(Nitlv_record);
disp('The number of remaining iterations');
disp(cal_number);
disp('---------------------------------------');


end
end

PE.Nitlv=Nitlv;

figure(1)
plot(PE.Gsam);title(['deltaGpa ',num2str(max(abs(diff(PE.Gsam)))/dt)])
axis([1 length(PE.Gsam)  -PE.Ga*1.2  PE.Ga*1.2])

figure(2)
plot(RO.Gsam);title(['deltaGra ',num2str(max(abs(diff(RO.Gsam)))/dt)])
axis([1 length(RO.Gsam)  -RO.Ga*1.2  RO.Ga*1.2])

figure(3)
plot(cumsum(PE.Gsam*dt*param.gama),cumsum(RO.Gsam*dt*param.gama),'.');
title(['Gpa: ',num2str(PE.Ga),' Gra:',num2str(RO.Ga),'  Point:',num2str(length(RO.Gsam)),'  Equivalent Point:',num2str(round(sqrt(length(RO.Gsam))))]);  
% set(gcf,'outerposition',get(0,'screensize'));
axis([-max(abs(real(C*1e2)))*1.2 max(abs(real(C*1e2)))*1.2  -max(abs(imag(C*1e2)))*1.2  max(abs(imag(C*1e2)))*1.2])


if ifsavedata==1 && optimizeG==1
%%
%-----------------------------------------
%===============�������ɳ���==============
%-----------------------------------------
datadir=['E:\Experiment Original Data\',param.filename,'\',param.ExperimentMode,'\',param.sample,'\',num2str(round(PE.sw/1e3)),'k',num2str(round(PE.Te*1e3)),...
    'ms_',num2str(round(RO.sw/1e3)),'k',num2str(round(RO.Te*1e3)),'ms_Lx',num2str(RO.L*1e3),'mm_Ly',num2str(PE.L*1e3),'mm_sampts_',num2str(length(RO.Gsam)),'_Gmax_',num2str(round(Gmax)),'_Smax_',num2str(round(Smax)),'_',date_hour,'_',date_minute,'_',date_second];
produce_Spiral_seq(PE,RO,datadir);

copyfile('produce_seq_Spiral_two_point.m',[datadir,'\']);
copyfile('E:\Data Processing\toolbox\model\1d.sav',[datadir,'\']);
copyfile('E:\Data Processing\toolbox\model\2d_45mm.par',[datadir,'\']);
copyfile('E:\Data Processing\toolbox\model\various ring.M0',[datadir,'\']);
end