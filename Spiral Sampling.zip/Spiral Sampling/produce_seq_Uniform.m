% ���ɶ�ά�ռ�����������
% by chenin 2013��6��17��16:58:59
ini;
addpath(strcat(pwd,'/produce2dSPENseq'));

%%
%-----------------------------------------
%==================ʱ���=================
%-----------------------------------------
date_now=datestr(now);
date_hour=num2str(hour(date_now));
date_minute=num2str(minute(date_now));
date_second=num2str(second(date_now));
time_now = [date,'_',date_hour,'_',date_minute,'_',date_second,'_'];

ifsavedata = 1;

%%
%-----------------------------------------
%==================��������=================
%-----------------------------------------
param.filename='Spiral sampling';
param.sample='Phantom_Uniform';
param.ExperimentMode='Simulation';
% param.ExperimentMode='Experiment';
param.gama=42.58e6;
dt = 4e-6;
PE.demandpoint=6996;
%-------------PE----------%
PE.L=45e-3;     % mm
PE.sw=64e3;     % Hz
PE.Te=4e-3;   % s
PE.Ge=PE.sw/(param.gama*PE.L);
PE.chirp=1; % 1����90�� 2����180��
PE.rd=0;  % �����
PE.ta=dt;
PE.step=64;
%-------------RO----------%
RO.L=45e-3;     % mm
RO.sw=32e3;     % Hz
RO.Te=4e-3;   % s
RO.Ge=RO.sw/(param.gama*RO.L);
RO.chirp=2; % 1����90�� 2����180��
RO.rd=0;  % �����
RO.ta=dt;
RO.step=64;

sampts=round(RO.step*PE.step);    % sampling points
Ta = dt*sampts;
RO.Ta = Ta;
PE.Ta = Ta;
PE.Smax = 0;
RO.Smax = 0;


%%
%-----------------------------------------
%===============��Ʋ����켣==============
%-----------------------------------------
PE.Gsam = zeros(1,sampts);
PE.Gsam(1:RO.step:end) = 1;
PE.Ga = -PE.Ge*PE.Te/(sum(PE.Gsam)*dt)*PE.chirp;
PE.Gsam = PE.Gsam*abs(PE.Ga);


RO.Gsam = ones(1,RO.step);
RO.Ga = -RO.Ge*RO.Te/(sum(RO.Gsam)*dt)*RO.chirp;
RO.Gsam = repmat([RO.Gsam*abs(RO.Ga),-RO.Gsam*abs(RO.Ga)],[1,round(PE.step/2)]);

figure
plot(cumsum(RO.Gsam),cumsum(PE.Gsam)); axis([-5 1.2*max(cumsum(RO.Gsam)) -5 1.2*max(cumsum(RO.Gsam))])
% figure
% plot(1:sampts,RO.Gsam);

if ifsavedata==1
%%
%-----------------------------------------
%===============�������ɳ���==============
%-----------------------------------------
datadir=['E:\Experiment Original Data\',param.filename,'\',param.ExperimentMode,'\',param.sample,'\',num2str(round(PE.sw/1e3)),'k_',num2str(round(PE.Te*1e3)),...
    'ms_',num2str(round(RO.sw/1e3)),'k_',num2str(round(RO.Te*1e3)),'ms_sampts_',num2str(length(RO.Gsam)),'_',date_hour,'_',date_minute,'_',date_second];
produce_2duniform_seq(PE,RO,datadir,time_now);

copyfile([mfilename,'.m'],[datadir,'\']);
copyfile('E:\Data Processing\toolbox\model\1d.sav',[datadir,'\']);
copyfile('E:\Data Processing\toolbox\model\2d_45mm.par',[datadir,'\']);
copyfile('E:\Data Processing\toolbox\model\Spiral_model.M0',[datadir,'\']);
end