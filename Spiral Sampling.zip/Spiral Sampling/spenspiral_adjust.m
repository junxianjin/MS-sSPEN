function spenspiral_adjust(dir)
% SPEN����������������
% by ���� 2015��1��16�� 11:08:46
close all;
addpath(strcat(pwd,'/myCS'));
addpath(strcat(pwd,'/utils'));
addpath(strcat(pwd,'/rwt-master'));
Shapelib_mat_dir = 'E:\Experiment Original Data\Spiral sampling\Shapelib\Mat\';
gama=2.6752e8;


for adjust_x = 0.7:0.1:1.3
    for adjust_y = 0.7:0.1:1.3


Para=getpar(dir,'delay2');
fidnum=length(Para.delay2);

roh_sum=0;
engery_record = zeros(1,fidnum);    % ��¼ԭʼ�ռ�����
for fidnumber=1:1:fidnum
% for fidnumber = 11
%%
%-----------------------------------------
%==================ʱ���=================
%-----------------------------------------
date_now=datestr(now);
date_hour=num2str(hour(date_now));
date_minute=num2str(minute(date_now));
date_second=num2str(second(date_now));
time=['_',date_hour,'_',date_minute,'_',date_second];

%%
%-----------------------------------------
%==================��������=================
%-----------------------------------------
param.Spiral = 1; % �ж��Ƿ������������ǵȼ��   0�ȼ��  1����
param.CS=0;
param.De_con=1;
param.correct=0;% ������λУ��

param.imshow = 0;  % �Ƿ���ʾͼ��  0 ����ʾ  1 ��ʾ

param.savedate=1;
param.simu=0;
param.iteration=8;
param.num=256;
%%
%------------------------------------%
%----------------��������------------%
%------------------------------------%
if param.simu==0
%     param.datadir='E:\Experiment Original Data\Spiral sampling\Experiment\16-Jan-2015_Phantom\SPENSpiral_64k3ms_32k3ms_Ga_16-999_Smax_85_FOV_40_6996.fid';
    param.datadir = dir;
    [RE,IM,NP,NB,NT,HDR]=load_fid(param.datadir,fidnumber);
    param.st=RE+1i*IM;
    Para=getpar(param.datadir,'p1_bw','pw1','lpe','pepat','gradpe','pp_bw','pp','lro','ropat','gradro','nread','nphase');
    PE.L = Para.lpe*1e-2;
    PE.sw = Para.p1_bw;
    PE.Te = Para.pw1;
    PE.Ga = Para.gradpe*1e-2;
    PE.pepat = Para.pepat;
    PE.Ge = PE.sw/(gama*PE.L)*2*pi;
    
    PE.chirp=1; % 1����90�� 2����180��
    
    RO.L = Para.lro*1e-2;
    RO.sw = Para.pp_bw;
    RO.Te = Para.pp;
    RO.Ga = Para.gradro*1e-2;
    RO.pepat = Para.ropat;
    RO.Ge = RO.sw/(gama*RO.L)*2*pi;
    RO.chirp=2;
    
    load([Shapelib_mat_dir,PE.pepat]);
    load([Shapelib_mat_dir,RO.pepat]);
    param.datadir=[param.datadir,'\'];
    
else 
    param.datadir='E:\Experiment Original Data\Spiral sampling\Simulation\Various_ring_Uniform\64k_4ms_32k_4ms_sampts_4096_20_2_39';
    param.datadir=[param.datadir,'\'];
    name='temp_Spiral_model';
    temp=dir([param.datadir,'*.mat']);
    temp=struct2cell(temp)';
    load([param.datadir,temp{1}]);  % ��������
    param.st=readtempccb2D([param.datadir,name,'.ccb'],PE,RO);   % ��������

end
temp = abs(param.st);
engery_record(fidnumber) = mean(temp(:).^2);

if param.savedate==1
%     savedatadir=[param.datadir,'\result_',num2str(fidnumber),'adjustx_',num2str(adjust_x),'adjusty_',num2str(adjust_y)];
    savedatadir=[param.datadir,'\result_adjustx',num2str(adjust_x),'_adjusty',num2str(adjust_y)];
    mymkdir(savedatadir);
    copyfile([mfilename,'.m'],[savedatadir,'\']);
    temp = imrotate(reshape(param.st,[Para.nread/2,Para.nphase+2]),-90);
    imwrite(abs(temp)/max(abs(temp(:))),[savedatadir,'\original.tif'],'tiff');
    if param.imshow == 1
        figure;plot(cumsum(RO_Gsam/32767),cumsum(PE_Gsam/32767),'.-','MarkerSize',5);
        set (gcf,'Position',[400,100,330*1.7,300*1.7]);
        saveas(gcf,[savedatadir,'\trajectory'],'bmp');
    end
    param.savedatadir = savedatadir;
end
if param.imshow == 1
    figure;
    plot(abs(param.st));title(num2str(length(param.st)));
end
PE.Ta = 4e-6*length(PE_Gsam);
RO.Ta = PE.Ta;

temp = 1;
while(PE_Gsam(temp)==0 && RO_Gsam(temp)==0)
    temp = temp+1;
end
PE.Gsam = PE_Gsam(temp:end);
RO.Gsam = RO_Gsam(temp:end);
param.st = param.st(temp:end);
param.st = param.st.*exp((1:length(param.st))/length(param.st)).'; % ǿ��У��
% PE.phasefactor=1;
% RO.phasefactor=1;
factor_x=-Smax*1e-3*adjust_x;
factor_y=-Smax*1e-3*adjust_y;
PE.phasefactor=1+factor_y;
RO.phasefactor=1-factor_x;
% param.sign2=1;
% PE.Ga = -PE.Ga;
% RO.Ga = -RO.Ga;
% PE.Ge = -PE.Ge;
% RO.Ge = -RO.Ge;

param.gama=gama;
PE_bk=PE;
RO_bk=RO;
param_bk=param;
%%
%------------------------------------%
%----------------�����ؽ�------------%
%------------------------------------%

if param.De_con==1
    param = param_bk;
    PE = PE_bk;
    RO = RO_bk;
    SPEN2D_calPmatrix
    Pr=Pmatrix2d(PE.P_matrix,RO.P_matrix);
    roh=Pr'*param.st;
    roh_sum=roh_sum+imrotate(abs(roh),90);
    param.method=['_De-con',num2str(fidnumber)];
%     postprocess_2D_SPEN(roh,PE,RO,param)
end


if param.CS==1
    param = param_bk;
    PE = PE_bk;
    RO = RO_bk;
    SPEN2D_calPmatrix
    xfmWeight = 1e-3;
    TVWeight = 0.5e-3;
    Itnlim=8;
%     XFM = Wavelet('Daubechies',6,6);
%     XFM = TIDCT(6,4);
    XFM = 1;
    myCS_2D
    param.method = ['_',method,num2str(fidnumber),'adjustx_',num2str(adjust_x),'adjusty_',num2str(adjust_y)];
    roh_sum=roh_sum+abs(roh);
%     postprocess_2D_SPEN(roh,PE,RO,param)
end
end
% figure;imshow(abs(roh_sum),[]);
imwrite(abs(roh_sum)/max(abs(roh_sum(:))),[savedatadir,'\roh_sum_adjustx',num2str(adjust_x),'_adjusty',num2str(adjust_y),'.tiff'],'tiff');
% 
% 
% figure;plot(engery_record,'.-');title(['��ֵ���죺',num2str(max(engery_record)-min(engery_record))]);
% saveas(gcf,[dir,'\data space energy'],'bmp');
close all;
    end
end
end


function postprocess_2D_SPEN(roh,PE,RO,param)

roh=imrotate(roh,-90);
if param.imshow == 1
    figure
    imshow(abs(roh),[],'InitialMagnification' ,'fit');title(param.method);
    figure
    imshow(angle(roh),[],'InitialMagnification' ,'fit');title(param.method);
end

if param.savedate==1
    if param.imshow == 1
        saveas(gcf,[param.savedatadir,'\SPENspiral_',num2str(round(PE.sw/1e3)),'k',num2str(PE.Te*1e3),'ms_',num2str(round(RO.sw/1e3)),'k',num2str(RO.Te*1e3),'ms',param.method],'fig');
    end
    imwrite(abs(roh)/max(abs(roh(:))),[param.savedatadir,'\SPENspiral_',num2str(round(PE.sw/1e3)),'k',num2str(PE.Te*1e3),'ms_',num2str(round(RO.sw/1e3)),'k',num2str(RO.Te*1e3),'ms',param.method,'.tiff'],'tiff');
    save([param.savedatadir,'\SPENspiral_',num2str(round(PE.sw/1e3)),'k',num2str(PE.Te*1e3),'ms_',num2str(round(RO.sw/1e3)),'k',num2str(RO.Te*1e3),'ms',param.method],'roh');
end
end
