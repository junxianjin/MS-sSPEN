% ϡ���ؽ����ĳ���
% by ľľ 2013��6��5��9:05:30
%--------------------------------CS-----------------------------%
method='SVD-CS';
param.st=param.st/norm(param.st);
PE.P_matrix=PE.P_matrix/norm(PE.P_matrix);
RO.P_matrix=RO.P_matrix/norm(RO.P_matrix);
Pr=Pmatrix2d(PE.P_matrix,RO.P_matrix);
data = param.st;
paramCS = init;
paramCS.FT = Pr;
paramCS.XFM = XFM;
paramCS.TV = TVOP;
paramCS.data = data;
paramCS.TVWeight =TVWeight;     % TV penalty 
paramCS.xfmWeight = xfmWeight;  % L1 wavelet penalty
paramCS.Itnlim = Itnlim;
tic
res = zeros(size(data));
NMSE.CS=[];
res_temp=res;
for n=1:1:param.iteration
    res = fnlCg(res,paramCS);
    im_res = XFM'*res;
    if param.imshow == 1
        figure(100), imshow(abs(fliplr(im_res)),[]),drawnow
    end
    NMSE.CS=[NMSE.CS,cal_NMSE(res,res_temp)];
    res_temp=res;
end
toc;
intime.CS=toc;
roh=im_res;

