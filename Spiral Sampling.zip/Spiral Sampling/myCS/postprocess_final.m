L=[L_pe,L_ro];
num_x=round(fft_number/max(L)*L_pe);
num_y=round(fft_number/max(L)*L_ro);
roh=imresize(abs(roh),[num_x num_y],'cubic');
[n,m]=size(roh);
filt=ones(m,1);
roh=abs(roh);
roh=roh/max(roh(:));
figure
imshow(abs(roh),[],'InitialMagnification' ,'fit');title(method);

if savedate==1
    saveas(gcf,[savedatadir,'\',num2str(round(sw_pe/1e3)),'k',method],'fig');
    imwrite(abs(roh)/max(abs(roh(:))),[savedatadir,'\',num2str(round(sw_pe/1e3)),'k',method,'.tiff'],'tiff');
    saveresult(roh,[savedatadir,'\',num2str(round(sw_pe/1e3)),'k',method]);
    save([savedatadir,'\',num2str(round(sw_pe/1e3)),'k',method],'roh');
end