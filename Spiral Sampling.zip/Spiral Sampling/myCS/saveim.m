function saveim(roh,name)
savedatadir='result';
mkdir(savedatadir);
savedatadir=[savedatadir,'\'];
figure;imshow(abs(roh),[],'InitialMagnification','fit');drawnow
saveas(gcf,[savedatadir,'\',name],'fig');
imwrite(abs(roh)/max(abs(roh(:))),[savedatadir,'\',name,'.tiff'],'tiff');
saveresult(roh,[savedatadir,'\',name]);
save([savedatadir,'\',name],'roh');
end