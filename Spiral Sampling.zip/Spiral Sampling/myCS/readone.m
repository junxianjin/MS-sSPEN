function st=readone(dir)
readout=load(dir);
num_0=length(readout)/2;
st=zeros(num_0,1);
for n=1:1:num_0
    st(n)=readout(2*n-1)+1i*readout(2*n);
end
end