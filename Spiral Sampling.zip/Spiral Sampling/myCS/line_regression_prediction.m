function estine=line_regression_prediction(destin_pha,chk,win_x_length,win_y_length,x,y,length_x,length_y)
temp_chk=zeros(win_x_length-1,win_y_length-1);
temp_pha=zeros(win_x_length-1,win_y_length-1);
estine=destin_pha(x,y);
for i=1:win_x_length-1
    for j=1:win_y_length-1
        temp_x=x-win_x_length/2+i;
        temp_y=y-win_y_length/2+j;
        if((temp_x>=1)&(temp_y>=1)&(temp_x<=length_x)&(temp_y<=length_y))
            temp_pha(i,j)=destin_pha(temp_x,temp_y);
            temp_chk(i,j)=chk(temp_x,temp_y);
        end
    end
end

number=0;
average_x=0;
for i=1:win_x_length-1
		for j=1:win_y_length-1
			average_x=temp_chk(i,j)*j;
			number=temp_chk(i,j)+number;
        end
end
if (number~=0)
average_x=average_x/number;
end

average_y=0;
for i=1:win_x_length-1
		for j=1:win_y_length-1
			average_y=temp_chk(i,j)*i;
        end
end
if (number~=0)
average_y=average_y/number;
end

average_z=0;
for i=1:win_x_length-1
		for j=1:win_y_length-1
			average_z=temp_chk(i,j)*temp_pha(i,j);
        end
end
if (number~=0)
average_z=average_z/number;
end

T=number;

sum_xx=0;
for i=1:win_x_length-1
		for j=1:win_y_length-1
			sum_xx=temp_chk(i,j)*j*j;
        end
end

sum_yy=0;
for i=1:win_x_length-1
		for j=1:win_y_length-1
			sum_yy=temp_chk(i,j)*i*i;
        end
end

sum_xy=0;
for i=1:win_x_length-1
		for j=1:win_y_length-1
			sum_xy=temp_chk(i,j)*i*j;
        end
end

sum_zx=0;
for i=1:win_x_length-1
		for j=1:win_y_length-1
			sum_zx=temp_chk(i,j)*temp_pha(i,j)*j;
        end
end

sum_zy=0;
for i=1:win_x_length-1
		for j=1:win_y_length-1
			sum_zy=temp_chk(i,j)*temp_pha(i,j)*i;
        end
end

if(T>1)
    tempd1=(sum_xx-T*average_x*average_x)*(sum_zy-T*average_y*average_z)-(sum_zx-T*average_x*average_z)*(sum_xy-T*average_x*average_y);
	tempd2=(sum_xy-T*average_x*average_y)*(T*average_x*average_y-sum_xy)+(sum_yy-T*average_y*average_y)*(sum_xx-T*average_x*average_x);
    if(abs(tempd2)>1.0e-5)
        gamar=tempd1/tempd2;
	   else gamar=0;
    end
    tempd1=sum_zx+T*gamar*average_x*average_y-gamar*sum_xy-T*average_x*average_z;
	tempd2=sum_xx-T*average_x*average_x;
    if(abs(tempd2)>1.0e-5)
        beta=tempd1/tempd2;
		else beta=0;
    end
    afar=average_z-beta*average_x-gamar*average_y;
    estine=afar+beta*win_x_length/2+gamar*win_y_length/2;
else
    for i=1:win_y_length-1
			for j=1:win_x_length-1
				if(temp_chk(i,j))
					estine=temp_pha(i,j);
					break;
                end
            end
    end
end












