method='CG';
clear roh;

expG=expG_back;
Gacqsj=zeros(1,number);
expG=[0;expG];
for n=2:1:number
    Gacqsj(n)=Gacqsj(n-1)+expG(n);
end
Oi=-gama*Gexc*Ly/2;
R=gama*Gexc*Ly/Texc;

real_y=Gacqsj*ta_pe/abs(Gexc*Texc)*Ly-Ly/2;
step_number=10;
% y_step=Ly/number;
y_step_step=(real_y(2)-real_y(1))/step_number;
t_step=ta_pe;
for x=1:number
    current_Gacqsj=Gacqsj(x)*t_step;
    for y=1:number
        current_y=real_y(y);
        temp_result_re=0;
        temp_result_im=0;
        for z=1:step_number
            current_angle=-Oi^2/(2*R)-(gama*Gexc*current_y)^2/(2*R)+gama*Gexc*Texc* current_y/2+gama*current_Gacqsj*current_y;
            temp_result_re=temp_result_re+y_step_step*cos(current_angle);
            temp_result_im=temp_result_im+y_step_step*sin(current_angle);
            current_y=current_y+y_step_step;
        end
        P_re(x,y)=temp_result_re;
        P_im(x,y)=temp_result_im;
    end
end 
P_matrix=P_re+1i*P_im;
% imshowP_matrix;
% P_matrix=imresize(P_matrix,[64 1024]);
P=P_matrix;
% [U,S,V] = svd(P_matrix);
% P_matrix=U*V';

x=zeros(size(st));
tic
[roh, k, NMSE.CG, Xnrm, Enrm] = my_CGLS(P_matrix, st, x, iteration, 1e-11);
toc
intime.CG=toc;

[U,S,V] = svd(P_matrix);
P_matrix=U*V';
roh=P_matrix'*st;

[N,M]=size(roh);
roh_temp=roh(1:N-1,:);
roh=roh_temp;
roh=imrotate(roh,90);