function estine=get_phase(chk,sourse,destin,i,j)
est1=0;est2=0;est3=0;est4=0;est5=0;est6=0;est7=0;est8=0;
number_deta=0;
PI2=2*pi;
if (chk(i+1,j))
    deta=sourse(i+1,j)-sourse(i,j);
    if (deta>pi)
        deta=deta-2*pi;
    elseif(deta<(-pi))
        deta=deta+2*pi;
    else
    end
    est1=destin(i+1,j)-deta;
    number_deta=number_deta+1;
end
if (chk(i-1,j))
    deta=sourse(i-1,j)-sourse(i,j);
    if (deta>pi)
        deta=deta-2*pi;
    elseif(deta<(-pi))
        deta=deta+2*pi;
    else
    end
    est2=destin(i-1,j)-deta;
    number_deta=number_deta+1;
end
if (chk(i,j-1))
    deta=sourse(i,j-1)-sourse(i,j);
    if (deta>pi)
        deta=deta-2*pi;
    elseif(deta<(-pi))
        deta=deta+2*pi;
    else
    end
    est3=destin(i,j-1)-deta;
    number_deta=number_deta+1;
end
if (chk(i,j+1))
    deta=sourse(i,j+1)-sourse(i,j);
    if (deta>pi)
        deta=deta-2*pi;
    elseif(deta<(-pi))
        deta=deta+2*pi;
    else
    end
    est4=destin(i,j+1)-deta;
    number_deta=number_deta+1;
end
if (chk(i-1,j-1))
    deta=sourse(i-1,j-1)-sourse(i,j);
    if (deta>pi)
        deta=deta-2*pi;
    elseif(deta<(-pi))
        deta=deta+2*pi;
    else
    end
    est5=destin(i-1,j-1)-deta;
    number_deta=number_deta+sqrt(2)/2;
end
if (chk(i+1,j+1))
    deta=sourse(i+1,j+1)-sourse(i,j);
    if (deta>pi)
        deta=deta-2*pi;
    elseif(deta<(-pi))
        deta=deta+2*pi;
    else
    end
    est6=destin(i+1,j+1)-deta;
    number_deta=number_deta+sqrt(2)/2;
end
if (chk(i-1,j+1))
    deta=sourse(i-1,j+1)-sourse(i,j);
    if (deta>pi)
        deta=deta-2*pi;
    elseif(deta<(-pi))
        deta=deta+2*pi;
    else
    end
     est7=destin(i-1,j+1)-deta;
    number_deta=number_deta+sqrt(2)/2;
end
if (chk(i+1,j-1))
    deta=sourse(i+1,j-1)-sourse(i,j);
    if (deta>pi)
        deta=deta-2*pi;
    elseif(deta<(-pi))
        deta=deta+2*pi;
    else
    end
    est8=destin(i+1,j-1)-deta;
    number_deta=number_deta+sqrt(2)/2;
end
est=(est1+est2+est3+est4+(est5+est6+est7+est8)*sqrt(2)/2)/number_deta;
% est=(est1+est2+est3+est4)/number_deta;
temp=round((est-sourse(i,j))/PI2);
estine=sourse(i,j)+temp*PI2;


