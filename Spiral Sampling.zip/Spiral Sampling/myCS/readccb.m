function st=readccb(dir,number)
% ��ʽ��st=readccb(dir,number)
% dirΪ����·��  
% numberΪfrydman����ά��
D=load(dir);
N_num=length(D);
number2=N_num/(2*number);
D_complex=zeros(1,N_num/2);
for n=1:1:N_num/2
    D_complex(n)=D(2*n-1)+1i*D(2*n);
end
st=zeros(number,number2);
count=1;
for m=1:1:number2
    for n=1:1:number
        st(n,m)=D_complex(count);
        count=count+1;
    end
end
end