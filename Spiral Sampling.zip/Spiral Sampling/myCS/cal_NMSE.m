function [NMSE,MSE]=cal_NMSE(A,B)
Imsz = size(A);
ngrid = Imsz(1)*Imsz(2);%���ԭͼ��Ĵ�С
A = double(reshape(A,1,ngrid));
B = double(reshape(B,1,ngrid));
sqr_err = (A-B)*(A-B)';
NMSE = sqr_err/(A*A');

if nargout==2
    MSE = sqr_err/ngrid;
end

end