function  average_xx=get_second_partial_derivation_x(sourse_pha,pos_x,pos_y)
PI2=2*pi;
value1=sourse_pha(pos_x-1,pos_y);
value2=sourse_pha(pos_x,pos_y);
value3=sourse_pha(pos_x+1,pos_y);
tempd=value1-value2;
if(tempd>pi)
    value1=value1-PI2;
end
if(tempd<-pi)
    value1=value1+PI2;
end
tempd=value3-value2;
if(tempd>pi)
       value3=value3-PI2;
end
if(tempd<-pi)
        value3=value3+PI2;  
end
average_xx=value1-2*value2+value3;

    
    
    
    
    
    
    
    
    
    
    
    
    
