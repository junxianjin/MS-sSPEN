%------------------------------------%
%----------------ȥ������λ------------%
%------------------------------------%
num=length(PE.Gsam);
Ta=4e-6;
Acqtime=Ta*num;
%-------------�����ݶȻ�ԭ��ʵֵ---------%
st=param.st;
Correct.TE=Acqtime/2;%%Correct.TE=Correct.TE1-Correct.TE2+PE.Te/2;
Correct.TE=PE.Te/2-Correct.TE;
[Correct.Omega,Correct.gimy,Correct.gimxy,Correct.gimx2,Correct.gimy2]=Hz2grad(Correct.fx,Correct.fy,Correct.fxy,Correct.fx2,Correct.fy2,RO.L,PE.L);
signy=1;
signx=1;
[sx_all,RO.L_fov]=trace_shim(RO.Gsam,RO.Ge,RO.Te,RO.L,RO.Ga,Ta,0,signx,2);
[sy_all,PE.L_fov]=trace_shim(PE.Gsam,PE.Ge,PE.Te,PE.L,PE.Ga,Ta,0,signy,1);
[sx,RO.L_fov1]=find_trace_all(RO.Gsam,sy_all,RO.Ge,RO.Te,RO.L,RO.Ga,0,Ta,Correct.Omega,Correct.Omega,Correct.gimy,Correct.gimxy,Correct.gimx2,Correct.TE,-1,1,0,1,1,1);
[sy,PE.L_fov1]=find_trace_all(PE.Gsam,sx_all,PE.Ge,PE.Te,PE.L,PE.Ga,0,Ta,Correct.Omega,Correct.gimy,Correct.Omega,Correct.gimxy,Correct.gimy2,Correct.TE,1,1,0,1,-1,2);
sign_x=1;
sign_y=1;
[RO.Ly]=dephase_all2(st,sx,sy,RO.Ge,RO.Te,RO.L,PE.Ge,PE.Te,PE.L,Ta,Correct.Omega,Correct.Omega,Correct.gimy,Correct.gimxy,Correct.gimx2,Correct.gimy2,sign_x,sign_y,gama,Correct.TE,-1);
xnum=256;
ynum=256;
[re,im]=grid_spiral1(sx,sy,RO.Ly,xnum,ynum,RO.L,PE.L,'cubic',1);
FID=re+im*1j;
param.st = FID;
RO.x=linspace(-RO.L/2,RO.L/2,xnum);
PE.y=linspace(-PE.L/2,PE.L/2,ynum);
cz.xnum=xnum;
cz.ynum=ynum;
%%
%------------------------------------%
%----------------����P����------------%
%------------------------------------%
recon.xnum=param.num;  % �ؽ����� 
recon.ynum=param.num;  % �ؽ����� 
recon.x=linspace(-RO.L/2,RO.L/2,recon.xnum);
recon.y=linspace(-PE.L/2,PE.L/2,recon.ynum);
RO.P_matrix=zeros(cz.xnum,recon.xnum);
for n=1:cz.xnum
    current_x=RO.x(n);
    for m=1:recon.xnum
        current_xx=recon.x(m);
        theta=(gama*RO.Ge*RO.Te*RO.chirp/(2*RO.L))*(current_xx-current_x).^2;
        RO.P_matrix(n,m)=exp(1i*theta);
    end
end
PE.P_matrix=zeros(cz.ynum,recon.ynum);
for n=1:cz.ynum
    current_y=PE.y(n);
    for m=1:recon.ynum
        current_yy=recon.y(m);
        theta=(gama*PE.Ge*PE.Te*PE.chirp/(2*PE.L))*(current_yy-current_y).^2;
        PE.P_matrix(n,m)=exp(1i*theta);
    end
end