function postprocess_2D_SPEN(roh,PE,RO,param)

roh=imrotate(roh,-90);
figure
imshow(abs(roh),[],'InitialMagnification' ,'fit');title(param.method);
if param.imshow == 1
    figure
    imshow(angle(roh),[],'InitialMagnification' ,'fit');title(param.method);
end

if param.savedate==1
    if param.imshow == 1
        saveas(gcf,[param.savedatadir,'\SPENspiral_',num2str(round(PE.sw/1e3)),'k',num2str(PE.Te*1e3),'ms_',num2str(round(RO.sw/1e3)),'k',num2str(RO.Te*1e3),'ms',param.method],'fig');
    end
    imwrite(abs(roh)/max(abs(roh(:))),[param.savedatadir,'\SPENspiral_',num2str(round(PE.sw/1e3)),'k',num2str(PE.Te*1e3),'ms_',num2str(round(RO.sw/1e3)),'k',num2str(RO.Te*1e3),'ms',param.method,'.tiff'],'tiff');
    save([param.savedatadir,'\SPENspiral_',num2str(round(PE.sw/1e3)),'k',num2str(PE.Te*1e3),'ms_',num2str(round(RO.sw/1e3)),'k',num2str(RO.Te*1e3),'ms',param.method],'roh');
end
end