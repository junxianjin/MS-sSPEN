function [min_value,vst,chk]=remove_invalid_point(amp,invalid_ratio,vst,chk)
average_amp=0;
[len,wid]=size(amp);
for i=1:len
    for j=1:wid
        average_amp=average_amp+amp(i,j);
    end
end
average_amp=average_amp/(len*wid);
min_value=average_amp*invalid_ratio;

for i=1:len
    for j=1:wid
        if(amp(i,j)<min_value)
            vst(i,j)=1;
            chk(i,j)=0;
        end
    end
end

for i=1:len
    for j=1:wid
       number=0;
       for i2=-3:3
           for j2=-3:3
               next_x=i+i2;
			   next_y=j+j2;
					if((next_y>=1)&(next_x>=1)&(next_y<=wid)&(next_x<=len)&(vst(i,j)==0))
						if(vst(next_x,next_y)==1)
                            number=number+1;
                        end
                    end
                    if(number>=30)
                        vst(i,j)=1;
                        chk(i,j)=0;
                    end
           end
       end
    end
end
for i=1:len
    for j=1:wid
       number=0;
       for i2=-3:3
           for j2=-3:3
               next_x=i+i2;
			   next_y=j+j2;
					if((next_y>=1)&(next_x>=1)&(next_y<=wid)&(next_x<=len)&(vst(i,j)==1))
						if(vst(next_x,next_y)==0)
                            number=number+1;
                        end
                    end
                    if(number>=30)
                        vst(i,j)=0;
                    end
           end
       end
    end
end

            
        
