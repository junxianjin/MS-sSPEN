function saveresult(st,name)
[n,m]=size(st);
fid=fopen([name,'.txt'],'w+');
for i=1:n
    for j=1:m
       fprintf(fid,'%-8g%-8g%-8g',st(i,j));
       fprintf(fid,'\t');
    end
end
fclose(fid);
end