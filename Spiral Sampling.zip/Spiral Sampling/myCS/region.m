% clear;
clc;
a=textread('phase.txt');
b=textread('amp.txt');
% a=pha;
% b=amp;
sourse_pha=reshape(a,320,240);
% for x=1:320
%     if mod(x,2)==0
%         for y=1:120
%             tt=sourse_pha(x,y);
%            sourse_pha(x,y)=sourse_pha(x,240-y+1);
%            sourse_pha(x,240-y+1)=tt;
%         end
%     end
% end
amp=reshape(b,320,240);
imshow(amp,[]); title('��ֵͼ');
figure
imshow(sourse_pha,[]); title('�����ǰ��λͼ');
invalid_ratio=0.4;
null_long=20;
null_width=20;
% destine_pha=region_grow1(sourse_pha,amp,invalid_ratio,null_long,null_width);
 destine_pha=region_grow2(sourse_pha,amp,invalid_ratio,null_long,null_width);
figure
imshow(destine_pha,[]); title('����ƺ���λͼ');
