method='De-convolution';
clear roh;
A=st;
[num_y,num_xx]=size(A);
Ly=L_pe;
Texc_y=Texc;
Gexc_y=Gexc;
Gacq_y=G_pe;
R_y=(gama*Gexc_y*Ly)/Texc_y;
Oiy=-gama*Gexc_y*Ly/2;
Tacq_y=abs(Gexc_y*Texc_y/Gacq_y);
% y_step=Ly/num_y;
Ay=gama*Gacq_y*Tacq_y/Ly;
sign=-1;
for x=1:num_xx
    st90=A(:,x);
    lzx(:,x)=lz90(st90,Oiy,R_y,Ay,Ly,sign);
end

if shiftfre==1
    lzx=freshift(lzx);
end

inter_num=20;
[mx]=get_m(Ay,Ly,num_y,expand_num,inter_num,2); 
for x=1:num_xx
    current_lzxx=lzx(:,x);
    current_lzx=fill_line(current_lzxx,expand_num);
    current_flzx=fft(current_lzx);
    flzx(:,x)=current_flzx;
end
fmxz=fft(mx);
num_yy=length(fmxz);
for x=1:num_xx
    for y=1:num_yy
        hxz(y,x)=flzx(y,x)/fmxz(y);
    end
end
for x=1:num_xx
    current_hxz=hxz(:,x);
    hz(:,x)=ifft(current_hxz);
end
roh=hz(1:num_yy/2,:);
roh=imresize(imrotate(abs(roh),90),[512 512],'cubic');