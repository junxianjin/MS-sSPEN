%------------------------------------%
%----------------ȥ������λ------------%
%------------------------------------%
PE.y = linspace(-PE.L/2,PE.L/2,PE.step).';
RO.x = linspace(-RO.L/2,RO.L/2,RO.step);

% gridimshow(param,PE,RO);
% figure;plot(PE.y);title('PE.y');
% figure;plot(RO.x);title('RO.x');

PE.adjust=repmat(exp(1i*(gama*PE.Ge*PE.Te*(PE.y).^2*PE.chirp)/(2*PE.L)),[1,RO.step]);
RO.adjust=repmat(exp(-1i*(gama*RO.Ge*RO.Te*(RO.x).^2*RO.chirp)/(2*RO.L)),[PE.step,1]);
param.st=param.st.*PE.adjust.*RO.adjust;

% st_odd = param.st(1:2:end,:);
% st_even = param.st(2:2:end,:);
% 
% for n=1:1:size(st_odd,1)
%     phase_correct=phase(st_even(n,:))-phase(st_odd(n,:));
%     param.st(2*n,:)=param.st(2*n,:).*exp(1i*phase_correct);
% end

figure;imshow(angle(param.st),[])

cz.xnum=param.num;
cz.ynum=param.num;

xi=linspace(-RO.L/2,RO.L/2,cz.xnum);
yi=linspace(-PE.L/2,PE.L/2,cz.ynum);
[XI,YI]=meshgrid(xi,yi);
% st_real = griddata(RO.x,PE.y,real(param.st),XI,YI,'linear');
% st_imag = griddata(RO.x,PE.y,imag(param.st),XI,YI,'linear');
% clc;
% param.st=st_real+1i*st_imag;

[RO.x,PE.y]=meshgrid(RO.x,PE.y);
param.st = griddata(RO.x,PE.y,param.st,XI,YI,'cubic');

% param.st(abs(param.st)<0.01*max(max(abs(param.st))))=0;
param.st(isnan(abs(param.st)))=0;

figure
imshow(abs(param.st),[],'InitialMagnification' ,'fit');
figure
imshow(angle(param.st),[],'InitialMagnification' ,'fit');
RO.x=xi;
PE.y=yi;
%%
%------------------------------------%
%----------------����P����------------%
%------------------------------------%
recon.xnum=param.num;  % �ؽ����� 
recon.ynum=param.num;  % �ؽ����� 
recon.x=linspace(-RO.L/2,RO.L/2,recon.xnum);
recon.y=linspace(-PE.L/2,PE.L/2,recon.ynum);
RO.P_matrix=zeros(cz.xnum,recon.xnum);
for n=1:cz.xnum
    current_x=RO.x(n);
    for m=1:recon.xnum
        current_xx=recon.x(m);
        theta=(gama*RO.Ge*RO.Te*RO.chirp/(2*RO.L))*(current_xx-current_x).^2;
        RO.P_matrix(n,m)=exp(1i*theta);
    end
end
PE.P_matrix=zeros(cz.ynum,recon.ynum);
for n=1:cz.ynum
    current_y=PE.y(n);
    for m=1:recon.ynum
        current_yy=recon.y(m);
        theta=(gama*PE.Ge*PE.Te*PE.chirp/(2*PE.L))*(current_yy-current_y).^2;
        PE.P_matrix(n,m)=exp(1i*theta);
    end
end
