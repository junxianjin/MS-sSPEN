function st=readtempccb2D(dir,PE,RO)
% st=cut_temp(dir,PE.step,RO.step);
[re im step s]=textread(dir);
st=re+im*1j;
end