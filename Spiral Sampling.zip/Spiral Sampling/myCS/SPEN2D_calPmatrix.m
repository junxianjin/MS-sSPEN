%------------------------------------%
%----------------ȥ������λ------------%
%------------------------------------%
% num=param.cut(2)-param.cut(1)+1;
num = length(PE.Gsam);
Ta=4e-6;

%-------------�����ݶȻ�ԭ��ʵֵ---------%
x = Ta*(1:num)*1e3 ;
% x=linspace(0,21.36,num);
% maxGrandient=max(PE.Gsam);
PE.Gsam=PE.Gsam/max(abs(PE.Gsam))*PE.Ga;
RO.Gsam=RO.Gsam/max(abs(RO.Gsam))*RO.Ga;

if param.savedate == 1 && param.imshow ==1
figure;
plot(x,PE.Gsam*1e2,'LineWidth',2.5);
title('Gy(t)','FontName','Times New Roman','FontSize',22,'fontweight','b')
xlabel('Time(ms)','FontName','Times New Roman','FontSize',22,'fontweight','b')
ylabel('Magnitude (G/cm)','FontName','Times New Roman','FontSize',22,'fontweight','b','Rotation',90)
% title('PSF','FontName','Times New Roman','FontSize',28,'fontweight','b','Rotation',0)
axis([0, max(x),min(PE.Gsam*1e2)*1.08,max(PE.Gsam*1e2)*1.08]);
set(gca,'FontName','Arial','FontSize',20,'fontweight','b','LineWidth',3,'GridLineStyle','--','TickDir','in')
set (gcf,'Position',[200,200,550*1.3,300*1.3], 'color','w')
% legend('Distortion trend')
saveas(gcf,[param.savedatadir,'\Gy(t)'],'fig');
saveas(gcf,[param.savedatadir,'\Gy(t).eps'],'epsc')

figure;plot(x,RO.Gsam*1e2,'LineWidth',2.5);
title('Gx(t)','FontName','Times New Roman','FontSize',22,'fontweight','b')
xlabel('Time(ms)','FontName','Times New Roman','FontSize',22,'fontweight','b')
ylabel('Magnitude (G/cm)','FontName','Times New Roman','FontSize',22,'fontweight','b','Rotation',90)
% title('PSF','FontName','Times New Roman','FontSize',28,'fontweight','b','Rotation',0)
axis([0, max(x),min(RO.Gsam*1e2)*1.08,max(RO.Gsam*1e2)*1.08]);
set(gca,'FontName','Arial','FontSize',20,'fontweight','b','LineWidth',3,'GridLineStyle','--','TickDir','in')
set (gcf,'Position',[200,200,550*1.3,300*1.3], 'color','w')
% legend('Distortion trend')
saveas(gcf,[param.savedatadir,'\Gx(t)'],'fig');
saveas(gcf,[param.savedatadir,'\Gx(t).eps'],'epsc')

% figure;plot(x(2:end),diff(RO.Gsam*1e2)/4e-3,'LineWidth',2.5);
% title('dGx(t)/dt','FontName','Times New Roman','FontSize',22,'fontweight','b')
% xlabel('Time(ms)','FontName','Times New Roman','FontSize',22,'fontweight','b')
% ylabel('Slew-rate(G/cm*ms)','FontName','Times New Roman','FontSize',22,'fontweight','b','Rotation',90)
% % title('PSF','FontName','Times New Roman','FontSize',28,'fontweight','b','Rotation',0)
% axis([0, max(x),min(diff(RO.Gsam*1e2)/4e-3)*1.1,max(diff(RO.Gsam*1e2)/4e-3)*1.1]);
% set(gca,'FontName','Arial','FontSize',20,'fontweight','b','LineWidth',3,'GridLineStyle','--','TickDir','in')
% set (gcf,'Position',[500,500,700*1.3,300*1.3], 'color','w')
% % legend('Distortion trend')
% saveas(gcf,[param.savedatadir,'\dGxdt'],'fig');
% 
% figure;plot(x(2:end),diff(PE.Gsam*1e2)/4e-3,'LineWidth',2.5);
% title('dGy(t)/dt','FontName','Times New Roman','FontSize',22,'fontweight','b')
% xlabel('Time(ms)','FontName','Times New Roman','FontSize',22,'fontweight','b')
% ylabel('Slew-rate(G/cm*ms)','FontName','Times New Roman','FontSize',22,'fontweight','b','Rotation',90)
% % title('PSF','FontName','Times New Roman','FontSize',28,'fontweight','b','Rotation',0)
% axis([0, max(x),min(diff(PE.Gsam*1e2)/4e-3)*1.1,max(diff(PE.Gsam*1e2)/4e-3)*1.1]);
% set(gca,'FontName','Arial','FontSize',20,'fontweight','b','LineWidth',3,'GridLineStyle','--','TickDir','in')
% set (gcf,'Position',[500,500,700*1.3,300*1.3], 'color','w')
% % legend('Distortion trend')
% saveas(gcf,[param.savedatadir,'\dGydt'],'fig');
end

PE.intGacq=cumsum(PE.Gsam)*Ta;
RO.intGacq=cumsum(RO.Gsam)*Ta;

param.intGacqy=PE.intGacq;
param.intGacqx=RO.intGacq;

if param.Spiral==1
    PE.y=PE.intGacq*PE.L/(PE.Ge*PE.Te*PE.chirp);
    RO.x=RO.intGacq*RO.L/(RO.Ge*RO.Te*RO.chirp);
else
    PE.y=PE.intGacq*PE.L/(PE.Ge*PE.Te*PE.chirp)+PE.L/2;
    RO.x=RO.intGacq*RO.L/(RO.Ge*RO.Te*RO.chirp)+RO.L/2;
end

if param.imshow == 1
    gridimshow(param,PE,RO);
    figure;plot(PE.y);title('PE.y');
    figure;plot(RO.x);title('RO.x');
end

if param.savedate == 1 && param.imshow ==1
    color_plot(RO.x,PE.y)   % ��ɫ�켣
    saveas(gcf,[param.savedatadir,'\trajectory.eps'],'psc2');
end

save([param.savedatadir,'\PERO'],'PE','RO');


if param.Spiral==1 && param.simu==0
    PE.adjust=exp(1i*gama*PE.Ge*PE.Te*(PE.y).^2*PE.chirp/(2*PE.L)*PE.phasefactor);
    RO.adjust=exp(-1i*gama*RO.Ge*RO.Te*(RO.x).^2*RO.chirp/(2*RO.L)*RO.phasefactor);
else
    PE.adjust=exp(1i*(gama*PE.Ge*PE.Te*(PE.y).^2*PE.chirp)/(2*PE.L));
    RO.adjust=exp(-1i*(gama*RO.Ge*RO.Te*(RO.x).^2*RO.chirp)/(2*RO.L));
end

if norm(size(param.st)-size(PE.adjust))~=0	% ά���Զ�У��
    param.st = param.st.';
end

param.st=param.st.*PE.adjust.*RO.adjust;

% gridimshow(param,PE,RO);

cz.xnum=param.num;
cz.ynum=param.num;

xi=linspace(-RO.L/2,RO.L/2,cz.xnum);
yi=linspace(-PE.L/2,PE.L/2,cz.ynum);
[XI,YI]=meshgrid(xi,yi);

% param.st = griddata(RO.x,PE.y,param.st,XI,YI,'nearest');
param.st = griddata(RO.x,PE.y,param.st,XI,YI);

param.st(isnan(abs(param.st)))=0;

if param.imshow == 1
figure
imshow(abs(param.st),[],'InitialMagnification' ,'fit');
figure
imshow(angle(param.st),[],'InitialMagnification' ,'fit');
end
RO.x=xi;
PE.y=yi;
%%
%------------------------------------%
%----------------����P����------------%
%------------------------------------%
recon.xnum=param.num;  % �ؽ����� 
recon.ynum=param.num;  % �ؽ����� 
recon.x=linspace(-RO.L/2,RO.L/2,recon.xnum);
recon.y=linspace(-PE.L/2,PE.L/2,recon.ynum);
RO.P_matrix=zeros(cz.xnum,recon.xnum);
for n=1:cz.xnum
    current_x=RO.x(n);
    for m=1:recon.xnum
        current_xx=recon.x(m);
        theta=(gama*RO.Ge*RO.Te*RO.chirp/(2*RO.L))*(current_xx-current_x).^2;
        RO.P_matrix(n,m)=exp(1i*theta);
    end
end
PE.P_matrix=zeros(cz.ynum,recon.ynum);
for n=1:cz.ynum
    current_y=PE.y(n);
    for m=1:recon.ynum
        current_yy=recon.y(m);
        theta=(gama*PE.Ge*PE.Te*PE.chirp/(2*PE.L))*(current_yy-current_y).^2;
        PE.P_matrix(n,m)=exp(1i*theta);
    end
end