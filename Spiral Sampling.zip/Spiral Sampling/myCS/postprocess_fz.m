method='blur';
L=[L_pe,L_ro];
num_x=round(fft_number/max(L)*L_pe);
num_y=round(fft_number/max(L)*L_ro);
roh=imresize(abs(roh),[num_x num_y],'cubic');
[n,m]=size(roh);
filt=ones(m,1);
roh=abs(roh/max(max(roh)));
figure
imshow(abs(roh),[],'InitialMagnification' ,'fit');
if savedate==1
    saveas(gcf,[savedatadir,'\',method],'fig');
    imwrite(abs(roh)/max(abs(roh(:))),[savedatadir,'\',method,'.tiff'],'tiff');
    saveresult(roh,[savedatadir,'\',method]);
    save([savedatadir,'\',method],'roh');
end
