function [st,prescan,orFID]=my_loadfry2(name,fft_number,calibration)
if nargin==1
    calibration=0;
end

[RE,IM,NP,NB,NT]=load_fid(name);
RE=RE';
IM=IM';
st=RE+1j*IM;
% [num num_x]=size(RE);
line=NT*NB;
num_y=line/2;
FID1=st(1:num_y,:);
FID=st(num_y+1:line,:);
for x=2:2:num_y
    FID(x,:)=fliplr(FID(x,:));
    FID1(x,:)=fliplr(FID1(x,:));
end
FID_bk=FID;

% fft_number=NP;
% fft_number=512;
% fft_number=256;
for y=1:num_y
    current=FID(y,:);
    currentt=fft(current,fft_number);
    temp(y,:)=fftshift(currentt);
end
FID=temp;


for y=1:num_y
    current=FID1(y,:);
    currentt=fft(current,fft_number);
    temp(y,:)=fftshift(currentt);
end
FID1_new=temp;

base=20;
pha=correct(FID1,base,fft_number);
% [N,M]=size(pha);
% xifen=4;
% line=round(linspace(80,400,xifen));
% pha_temp=[];
% for n=1:1:length(line)
%     line1=pha(:,line(n));
%     temp=repmat(line1,[1,M/xifen]);
%     pha_temp=[pha_temp,temp];
% end

% pha=pha_temp;
pha(:,196:300)=0;
if calibration==1
    FID=FID.*exp(1i*pha);
end

st=FID;
if nargout == 2
    prescan=pha;
end

if nargout ==3
    prescan=pha;
%     orFID=FID_bk;
    orFID=FID1_new;
end
end

function pha_correct=correct(prescan,num,fill_number)
[numy numx]=size(prescan);
% pha_correct=zeros(numy,numx);
base=fft(prescan(num,:),fill_number);
base=fftshift(base);
base_pha=angle(base);
for y=1:numy
    current_fid=prescan(y,:);
    current_fft=fft(current_fid,fill_number);
    current_fft=fftshift(current_fft);
    current_pha=angle(current_fft);
    pha_correct(y,:)=-current_pha;
end
end