% clear;
ini;
load('E:\Experiment Original Data\Further improve solution\Experiment\Lemon\Data\gems_7070mm_6464.fid\GEMS')
% roh=result;
sourse_pha=angle(roh);
amp=abs(roh);
imshow(amp,[]); title('��ֵͼ');
figure
imshow(sourse_pha,[]); title('�����ǰ��λͼ');
invalid_ratio=2;
null_long=20;
null_width=20;
% destine_pha=region_grow1(sourse_pha,amp,invalid_ratio,null_long,null_width);
destine_pha=region_grow2(sourse_pha,amp,invalid_ratio,null_long,null_width);
figure
imshow(destine_pha,[]); title('����ƺ���λͼ');
