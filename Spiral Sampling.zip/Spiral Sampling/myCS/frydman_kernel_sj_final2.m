% frydmanʵ�鴦������
% by chenlin 2012��12��25��15:05:20

%------------------ȥ������λ---------------------%
method='CS';
clear roh;
% cz=4;
% fft_number=512;
Gint=zeros(number,1);
expG=[0;expG];
Gint(1)=expG(1);
for n=2:1:stepnum_pe
    Gint(n)=Gint(n-1)+expG(n);
end
z2=ta_pe*Gint*L_pe/(Gexc*Texc)+L_pe/2;
% z2=linspace(L_pe/2,-L_pe/2,number).';
% figure
% plot(z2)
% z_cz=(linspace(Ly/2,-Ly/2,fft_number)+0.005*(rand(1,fft_number)-0.5)*Ly).';
z_cz=(linspace(Ly/2,-Ly/2,fft_number)).';
Oi=-gama*Gexc*L_pe/2;
A=-gama*Gexc*Texc/L_pe;
adjust=exp(1i*( Oi^2/(2*R) +  A*z2.^2/2 ));
number_y=size(st,2);
for n=1:1:number_y
    st(:,n)=st(:,n).*adjust;
end
if shiftfre==1
    st=freshift(st);
end
for n=1:1:number_y
    temp_real(:,n)=interp1(z2,real(st(:,n)),z_cz,'cubic');
    temp_imag(:,n)=interp1(z2,imag(st(:,n)),z_cz,'cubic');
end
st=temp_real+1i*temp_imag;
% figure
% imshow(angle(st),[],'InitialMagnification','fit');title('angle after');
number_y=length(z_cz);
st=imresize(st,[number_y number_y],'cubic');
% ------------------�ع�------------------%
z=linspace(Ly/2,-Ly/2,number_y)';
% z=linspace(max(z2),min(z2),number_y)';
xifen=4;
z_step=(z(2)-z(1))/xifen;
% tolerance=500;
for n=1:1:length(z_cz)
    zn=z_cz(n);
    for m=1:1:number_y
        zm=z(m);
        temp_cos=0;
        temp_sin=0;
        average_number=0;
        for k=1:1:xifen
            zz=zm+(k-1)*z_step;
            alpha=A*(zz-zn)^2/2  -  (gama*Gexc*zz)^2/(2*R) + gama*Gexc*Texc*zz/2 + ...
                gama*Gacq*zz*max(Tacq)/2  - A*zz^2/2;
            temp_cos=temp_cos+cos(alpha);
            temp_sin=temp_sin+sin(alpha);
            average_number=average_number+1;
        end
        temp_cos=temp_cos/average_number;
        temp_sin=temp_sin/average_number;
        P_matrix_temp=(temp_cos+1i*temp_sin);
        filt(n,m)=exp(-((zn-zm)/L_pe*100).^2/tolerance);
        P_matrix(n,m)=P_matrix_temp;
    end
end
if addfilt==1
    P_matrix=P_matrix.*filt;
end
[U,S,V]=svd(P_matrix);
P_matrix=U*V';