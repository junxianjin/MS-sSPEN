% ϡ���ؽ����ĳ���
% by ľľ 2013��6��5��9:05:30
%--------------------------------CS-----------------------------%
method='SVD-CS';
% im=P_matrix'*st;
% im_back=im;
% im=fliplr(imrotate(im,90));
% im=im/max(max(abs(im)));
% N = size(im); 		% image Size
% FT = p2DFT(true(size(im)), size(im), 1, 2);
st=st/max(max(abs(st)));
P_matrix=P_matrix/max(max(abs(P_matrix)));
% P_matrix=P_matrix/norm(P_matrix);
data = st;

param = init;
param.FT = Pmatrix(P_matrix);
param.XFM = XFM;
param.TV = TVOP;
param.data = data;
param.TVWeight =TVWeight;     % TV penalty 
param.xfmWeight = xfmWeight;  % L1 wavelet penalty
param.Itnlim = Itnlim;
tic
res = zeros(size(data));
NMSE.CS=[];
res_temp=res;
for n=1:1:iteration
    res = fnlCg(res,param);
    im_res = XFM'*res;
    figure(100), imshow(abs(fliplr(imrotate(im_res,90))),[]),drawnow
    NMSE.CS=[NMSE.CS,cal_NMSE(res,res_temp)];
    res_temp=res;
end
toc;
intime.CS=toc;

roh=abs(im_res);
roh=fliplr(imrotate(roh,90));
roh=roh/max(roh(:));


