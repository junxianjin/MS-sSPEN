function gridimshow(param,PE,RO)
gridnum=250; % ���񻯵���
index = find(param.st~=0);
st = param.st(index); %  �����ź�
x = RO.x(index) + RO.L/2; % ������Χ��0~L   
y = PE.y(index) + PE.L/2;
Ly = PE.L;
Lx = RO.L;
delta_x = Lx/gridnum;
delta_y = Ly/gridnum;

gridimage=zeros(gridnum+10,gridnum+10);

for k = 1:1:length(st)
    m = round(x(k)/delta_x)+10;
    n = round(y(k)/delta_y)+10;
    gridimage(n,m) = st(k);
end
figure;
imshow(abs(gridimage),[]);%colormap(jet)
figure;
imshow(angle(gridimage),[]);%colormap(jet)
end