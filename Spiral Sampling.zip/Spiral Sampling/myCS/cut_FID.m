function fid=cut_FID(st,param,SRparam)
fid=zeros(param.steppe,param.stepro);
for y=1:param.steppe
    for x=1:param.stepro
        fid(y,x)=st((y-1)*param.stepro+x);
    end
end

%------------------------------
% chemical shift correction 
% if SRparam.ro_chemshiftcorrect==1
%     t=linspace(0,param.samptimero,param.stepro);
%     CScorrect=diag(exp(-1i*2*pi*(param.wcs*t)));
%     fid=fid*CScorrect;
% end
%------------------------------

for y=1:param.steppe
    if mod(y,2)==0
        if SRparam.simu==1
            fid(y,:)=circshift(fid(y,:),[1,1]);
        end
        fid(y,:)=fliplr(fid(y,:));
    end
end

end