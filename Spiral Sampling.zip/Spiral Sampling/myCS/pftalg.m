method='PFT';
clear roh;
a=gama*gama*Gexc*Gexc/(2*R);
b=gama*gama*Gexc*Gexc*Ly/(2*R);
c=gama*gama*Gexc*Gexc*Ly*Ly/(8*R);
d=gama*Gacq;
y_step=Ly/number;
t_step=Tacq/number;
P_re=zeros(number,number);
P_im=zeros(number,number);
for x=1:number
    current_t=x*t_step;
    for y=1:number
        current_y=-Ly/2+(y-1)*y_step;
            current_angle=-a*current_y*current_y+b*current_y-c-pi/2+d*current_t*current_y;
            temp_result_re=cos(current_angle);
            temp_result_im=sin(current_angle);
        P_re(x,y)=temp_result_re/y_step;
        P_im(x,y)=temp_result_im/y_step;
    end
end 

P_matrix=P_re+1i*P_im;
P=P_matrix;
% imshowP_matrix;
% tolerance=50;
x=1:1:number;
filt=zeros(size(P_matrix));
for k=1:number
    filt(k,:)=exp(-(x-(number-k)).^2/tolerance);
end
P_matrix=P_matrix.*filt;
% imshowP_matrix
roh=P_matrix'*st;
roh=imrotate(roh,90);