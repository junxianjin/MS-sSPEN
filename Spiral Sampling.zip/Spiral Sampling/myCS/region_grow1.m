%������������λ���Ƴ���
function destin_pha=region_grow1(sourse_pha,amp,invalid_ratio,null_long,null_width)
%��ʼ��
[long,width]=size(sourse_pha);
destin_pha=sourse_pha;
est_pha=sourse_pha;
% destin_pha=zeros(long,width);
% est_pha=zeros(long,width);
vst=zeros(long,width);
chk=zeros(long,width);
q_matrix=zeros(long,width);
min_q_value=3.0e33;max_q_value=-3.0e33;
n_stack=5;
min_pha=3e33;max_pha=3e-33;
range1=3;range2=1;
PI2=2*pi;
 %�ҳ������С��λ��
for i=null_long:long-null_long
    for j=null_width:width-null_width
        if(sourse_pha(i,j)>max_pha)
            max_pha=sourse_pha(i,j);                                       
        elseif(sourse_pha(i,j)<min_pha)
            min_pha=sourse_pha(i,j);
        end
    end
end
 %ȥ��Ч��
 [min_value,vst,chk]=remove_invalid_point(amp,invalid_ratio,vst,chk);   
%  figure(4)
%  imshow(vst,[]);
%��ȡ��Ч��λ��������ֲ�ͼ
for i=null_long:long-null_long
    for j=null_width:width-null_width
        if(vst(i,j)==0)
           average_devia_xx=0;
           average_devia_yy=0;
           temp=0;temp_sumx=0;temp_sumy=0;
           for i2=-range1:range1
               for j2=-range1:range1
               average_devia_xx=average_devia_xx+get_second_partial_derivation_x(sourse_pha,i+i2,j+j2);
               average_devia_yy=average_devia_yy+get_second_partial_derivation_y(sourse_pha,i+i2,j+j2);                             
               end
           end
           average_devia_xx=average_devia_xx/((2*range1+1)*(2*range1+1));
           average_devia_yy=average_devia_yy/((2*range1+1)*(2*range1+1));
           for i2=-range1:range1
               for j2=-range1:range1
               temp=get_second_partial_derivation_x(sourse_pha,i+i2,j+j2);
               temp_sumx=temp_sumx+(temp-average_devia_xx)*(temp-average_devia_xx);
               end
           end
            for i2=-range1:range1
               for j2=-range1:range1
               temp=get_second_partial_derivation_y(sourse_pha,i+i2,j+j2);
               temp_sumy=temp_sumy+(temp-average_devia_yy)*(temp-average_devia_yy);
               end
            end
            temp=(sqrt(temp_sumx)+sqrt(temp_sumy))/((2*range1+1)*(2*range1+1));
		    q_matrix(i,j)=sqrt(temp);
           if temp<min_q_value
               min_q_value=temp;
               seed_x=i;
               seed_y=j;
           end
           if temp>max_q_value
               max_q_value=temp;
           end
        end
    end
end
q_value_step=(max_q_value-min_q_value)/n_stack;
% figure(5)
% imshow(q_matrix,[])
for i=1:n_stack
	m_quality_team(i).head=1;
    m_quality_team(i).tail=1;
end
m_quality_team(1).tail=m_quality_team(1).tail+1;
m_quality_team(1).pixel(1).x=seed_x;
m_quality_team(1).pixel(1).y=seed_y;
vst(seed_x,seed_y)=1;
finish=false;
first=true;
% b=0;
while((finish==false))
    finish=true;
    for i=1:n_stack
        if(m_quality_team(i).head~=m_quality_team(i).tail)
            seed_x=m_quality_team(i).pixel(m_quality_team(i).head).x;
			seed_y=m_quality_team(i).pixel(m_quality_team(i).head).y;
			finish=false;
			m_quality_team(i).head=m_quality_team(i).head+1;
			break;
        end
    end
        if(finish==false)
            for i3=-range2:range2
                for j3=-range2:range2
                    new_x=seed_x+j3;
					new_y=seed_y+i3;
                    if(((i3~=0)|(j3~=0))&(new_x>=null_long)&(new_y>=null_long)&(new_x<=(long-null_long))&(new_y<=(width-null_long))&(vst(new_x,new_y)==0))
                        vst(new_x,new_y)=1;
						current_stack_id=floor((q_matrix(new_x,new_y)-min_q_value)/q_value_step)+1;
                        if(current_stack_id>n_stack)
                            current_stack_id=n_stack-1;
                        end
                        m_quality_team(current_stack_id).pixel(m_quality_team(current_stack_id).tail).x=new_x;
                        m_quality_team(current_stack_id).pixel(m_quality_team(current_stack_id).tail).y=new_y;
                        m_quality_team(current_stack_id).tail=m_quality_team(current_stack_id).tail+1;
                    end
               end
            end
        end
        win_x_length=8;                          %ʵ��Ϊ7*7����
        win_y_length=8;
        

        
         if(first)
              first=false;
              chk(seed_x,seed_y)=1;
              destin_pha(seed_x,seed_y)=sourse_pha(seed_x,seed_y);
%               if (b<20)
%                   first=true;
%                   b=b+1;
%               end
         elseif (amp(seed_x,seed_y)>min_value)
             est_pha(seed_x,seed_y)=line_regression_prediction(destin_pha,chk,win_x_length,win_y_length,seed_x,seed_y,long,width);
             temp=(est_pha(seed_x,seed_y)-sourse_pha(seed_x,seed_y))/PI2;
%              if(temp>0)
%                  temp=fix(temp+0.5);
%              else
%                  temp=fix(temp-0.5);
             
                 temp=round(temp);
				 destin_pha(seed_x,seed_y)=sourse_pha(seed_x,seed_y)+PI2*temp;
%              if(destin_pha(seed_x,seed_y)>max_pha)
%                  destin_pha(seed_x,seed_y)=max_pha;
%              end
%              if(destin_pha(seed_x,seed_y)<min_pha)
%                  destin_pha(seed_x,seed_y)=min_pha;
%              end
             chk(seed_x,seed_y)=1;
         else
             est_pha(seed_x,seed_y)=line_regression_prediction(destin_pha,destin_pha,win_x_length,win_y_length,seed_x,seed_y,long,width);
%              if(est_pha(seed_x,seed_y)>max_pha)
%                  est_pha(seed_x,seed_y)=max_pha;
%              end
%              if(est_pha(seed_x,seed_y)<min_pha)
%                  est_pha(seed_x,seed_y)=min_pha;
%              end
             destin_pha(seed_x,seed_y)=est_pha(seed_x,seed_y);
             chk(seed_x,seed_y)=1;
         end
end
% figure(6)
% imshow(chk,[])











            
