function [PE,RO]=SamGRD_experiment(PE,RO)
% �������еĲ����ݶȣ�Ȼ������޸�

temp=load('epipp_raser_ro102.txt');
RO.diffx=temp(:,1);
RO.diffx=RO.diffx/sum(RO.diffx(1:102))*RO.L;

temp=load('epipp_raser_pe102.txt');
PE.diffy=temp(:,1);
PE.diffy(1:234)=0;
PE.diffy=PE.diffy/sum(PE.diffy(:))*PE.L;

Rand.point=6732;    % ��������
Tacq=Rand.point*4e-6;
PE.Tacq=Tacq;
RO.Tacq=Tacq;
tacq=Tacq/Rand.point;

PE.Gsam=PE.diffy*PE.Gexc*PE.Texc*PE.chirp/(PE.L*tacq);  % ��λά�����ݶ�
PE.Gsam=PE.Gsam+PE.rd*(rand(size(PE.Gsam))-0.5)*max(PE.Gsam);
PE.Gsam=PE.Gsam(1:Rand.point);
figure
plot(PE.Gsam);
PE.Gacq=-sign(PE.Gexc)*max(PE.Gsam);
PE.Gsam=PE.Gsam/max(PE.Gsam);

RO.Gsam=RO.diffx*RO.Gexc*RO.Texc*RO.chirp/(RO.L*tacq);  % Ƶ��ά�����ݶ�
RO.Gsam=RO.Gsam+RO.rd*(rand(size(RO.Gsam))-0.5)*max(RO.Gsam);
RO.Gsam=RO.Gsam(1:Rand.point);
RO.Gacq=-sign(RO.Gexc)*max(abs(RO.Gsam));
RO.Gsam=RO.Gsam/max(abs(RO.Gsam));

figure
plot(RO.Gsam,'.');  
title(num2str(length(RO.Gsam)));  
% title(num2str(length(RO.Gsam)/(RO.sw*RO.Texc*PE.Texc*PE.sw)));
% hold on 
% plot(PE.Gsam,'r.');

PE.samplerate=round(Rand.point/(RO.sw*RO.Texc*PE.sw*PE.Texc)*100);
RO.samplerate=PE.samplerate;
end