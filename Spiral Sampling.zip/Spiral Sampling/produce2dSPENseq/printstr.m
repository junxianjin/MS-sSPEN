function printstr(str,dir2,A)
txt_dir=[dir2,A,'.txt'];
a= str;
FID=fopen(txt_dir,'wt');
fprintf(FID, '%c', a);
fclose(FID);
end