function produce_Spiral_seq(PE,RO,datadir,time_now)
%   ��ά�����޸ļ���������
%   by ľľ 2013��3��14��9:25:22
%%
% // for PULSE value1 is angle, value2 is datadirection, value3 is hard_pulse, is_sampling is for full.
% //for PULSE  value10,value11,value12  is for gx, gy, gz;
% //for PULSE value7 is for pulse during time.
% //for PULSE value8 is for frequence offset
% // for FREE_INDUCE value1 is time, value2 is g, value3 is sample_times,vlaue4 is zero for constant , positive for increasing ,minus for decreasing.
% // for Acqu   value1 is phase, value2 is g_z, value5 is g_x,value6 is g_y;  
% //for Bloch  value2 is g_z, value5 is g_x,value6 is g_y;
% //for IMAGE value4 represented whether phase gradient is needed
% //for InSm2D  value13 represented whether phase gradient is needed
% // for free_induce, but for sampling, value7 is phase
% // for pulse m_name is pulse_name, m_name2 is grad_name 
% // for induce  m_name is grad_name
% struct sequence_team{
% 	double value1,value2; 
% 	int value3,value4;
% 	double value5,value6;
% 	double value7,value8,value9;
% 	double value10,value11,value12;  
% 	int value13,value14,value15,value16; //value16: ���弰������ʱ��Ϊ��λ����
% 	BOOL type,is_sampling;
% 	char m_name[MAX_NAME/2];  //grad_name
% 	char m_name2[MAX_NAME/2];  //pulse_name
% 	double values[MAX_PHASE_NUMBER];   //����ʱ��Ϊ��λ����

% Pulse(1) Flip Angle /pi
% Pulse(6) Time
% Pulse(7) Freq Offset
% Pulse(9) Gx
% Pulse(10) Gy
% Pulse(11) Gz
% 
% Gradient(1) Time
% Gradient(2) Gz
% Gradient(4) Gx
% Gradient(5) Gy

%-----------------------------%
%--------   ��������    ------%
%-----------------------------%
cd=78;  % ÿ��������ַ���
sourcedatadir='chirp90chirp180hard180.seq';
fid = fopen(sourcedatadir,'r');
seq=fread(fid,'int32');
fclose(fid);
seq=int32(seq);
fid2 = fopen('test_frydaman_temp.txt','w');
touwenjian=seq(1);  %ͷ�ļ� 4���ֽ�
seq2=seq(2:1:end);  %ȡ�м����в���
%------------ת����double-------------%
fwrite(fid2,seq2,'int32');
fclose(fid2);
fid2 = fopen('test_frydaman_temp.txt','r');
seq3=fread(fid2,'double');
fclose(fid2);


%%
%-------------------------------------------%
%----------------  �޸ĺ���  ---------------%
%-------------------------------------------%
% Hard90=seq3(1:1:cd);
% Chirp180z=seq3(cd+1:1:2*cd);
% Gradientz=seq3(2*cd+1:1:3*cd);
% Chirp180x=seq3(3*cd+1:1:4*cd);
% Gradientx=seq3(4*cd+1:1:5*cd);
% Sample=seq3(5*cd+1:1:6*cd);
% Acq=seq3(6*cd+1:1:7*cd);

Chirp90z=seq3(1:1:cd);
Gradientz=seq3(cd+1:1:2*cd);
Chirp180x=seq3(2*cd+1:1:3*cd);
Hard180=seq3(3*cd+1:1:4*cd);
Gradientx=seq3(4*cd+1:1:5*cd);
Sample=seq3(5*cd+1:1:6*cd);
Acq=seq3(6*cd+1:1:7*cd);

%---------Chirp90z-------%
Chirp90z(11)=PE.Ge;
Chirp90z(6)=PE.Te;

%---------Chirp180x-------%
Chirp180x(9)=RO.Ge;
Chirp180x(6)=RO.Te;

%---------Gradientz-------%
Gradientz(2)=-PE.Ge/2*PE.chirp;
Gradientz(1)=PE.Te;

%---------Gradientx-------%
% Gradientx(4)=-RO.Ge/2*RO.chirp;
% Gradientx(1)=RO.Te;

%---------Sample-------%
Sample(4)=RO.Ga;
Sample(2)=PE.Ga;
Sample(1)=RO.Ta;

%----------�ϲ��µ�seq3-------%
% seq3=[Chirp90z;Gradientz;Chirp180x;Hard180;Gradientx;Sample;Acq];
seq3=[Chirp90z;Chirp180x;Hard180;Gradientz;Sample;Acq];
%%
fid3 = fopen('test_frydaman_temp2.txt','w');
fwrite(fid3,seq3,'double');
fclose(fid3);
%---------���޸ĺõ�value2��ͷ�ļ����------%
fid3 = fopen('test_frydaman_temp2.txt','r');
seq4=fread(fid3,'int32');
fclose(fid3);
seq4=[touwenjian;seq4];
mkdir(datadir);
datadir=[datadir,'\'];
fid4 = fopen([datadir,'Spiral_sampts_',num2str(length(PE.Gsam)),'.seq'],'w');
fwrite(fid4,seq4,'int32');
fclose(fid4);

%%
%----------����chirp����-------%
mychirp(PE.sw,PE.Te,[datadir,'chirp_',num2str(round(PE.sw/1e3)),'k_',num2str(round(PE.Te*1e3)),'ms_cl']);
mychirp(RO.sw,RO.Te,[datadir,'chirp_',num2str(round(RO.sw/1e3)),'k_',num2str(round(RO.Te*1e3)),'ms_cl']);


%%
%------------����켣------------%
figure
plot(cumsum(PE.Gsam),cumsum(RO.Gsam),'.');
title(['Gpa: ',num2str(PE.Ga),' Gra:',num2str(RO.Ga),'  Point:',num2str(length(RO.Gsam)),'  Equivalent Point:',num2str(round(sqrt(length(RO.Gsam)))), ' Circle:',num2str(PE.Nitlv)]);  
axis([-max(abs(cumsum(PE.Gsam)))*1.2 max(abs(cumsum(PE.Gsam)))*1.2  -max(abs(cumsum(RO.Gsam)))*1.2  max(abs(cumsum(RO.Gsam)))*1.2])
saveas(gcf,[datadir,'trajectory'],'tiff');

%------------����ģ���ݶ��ļ�----------%
Grandmax=32767; % �ݶ��ļ����ֵ
RO.Gsam=round(RO.Gsam/max(abs(RO.Gsam))*Grandmax);  % ��һ��
PE.Gsam=round(PE.Gsam/max(abs(PE.Gsam))*Grandmax);

num=length(PE.Gsam);
Ga=zeros(num,3);
Ga(:,1)=RO.Gsam;
Ga(:,3)=PE.Gsam;
da=['Spiral_sampts_',num2str(length(PE.Gsam))];
fid=fopen([datadir,da,'.GRD'],'w+');
for n=1:1:num
    for m=1:1:3
        fprintf(fid,'%-8g%-8g%-8g',Ga(n,m));
        fprintf(fid,'\t');
    end
    fprintf(fid,'\n');
end
fclose(fid);

%------------����ʵ���ݶ��ļ�----------%
modify2dGRD(datadir,PE,RO,time_now);

%%
%---------�������---------%
save([datadir,'param'],'PE','RO');
delete('test_frydaman_temp.txt')
delete('test_frydaman_temp2.txt')
end
