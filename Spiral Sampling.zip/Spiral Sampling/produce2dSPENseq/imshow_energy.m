function imshow_energy(PE,RO)
PE.track=cumsum(PE.Gsam);
RO.track=cumsum(RO.Gsam);
PE.y=PE.ta*PE.track*PE.L/(PE.Ge*PE.Te*PE.chirp);
RO.x=RO.ta*RO.track*RO.L/(RO.Ge*RO.Te*RO.chirp);
gridnum=64;
delta_y=PE.L/gridnum;
delta_x=RO.L/gridnum;
energy=zeros(gridnum,gridnum);
for n=1:1:length(PE.y)
    y = floor((PE.y(n)+PE.L/2)/delta_y);
    x = floor((RO.x(n)+RO.L/2)/delta_x);
    if x>gridnum
        x=gridnum;
    end
    if x<1
        x=1;
    end
    if y>gridnum
        y=gridnum;
    end
    if y<1
        y=1;
    end
    energy(x,y)=energy(x,y)+1;
end
gaussianFilter = fspecial('gaussian', [3, 3], 10);
energy = imfilter(abs(energy), gaussianFilter, 'circular', 'conv');
figure(20);imshow(abs(energy),[]);drawnow
end
    
           
