function modify2dGRD(dir2,PE,RO,time_now)
Shapelib_dir = 'E:\Experiment Original Data\Spiral sampling\Shapelib\GRD';
if exist(Shapelib_dir,'file')==0
    mkdir(Shapelib_dir);
end
Shapelib_dir=[Shapelib_dir,'\'];
Shapelib_mat_dir = 'E:\Experiment Original Data\Spiral sampling\Shapelib\Mat';
if exist(Shapelib_mat_dir,'file')==0
    mkdir(Shapelib_mat_dir);
end
Shapelib_mat_dir = [Shapelib_mat_dir,'\'];

PEGa = PE.Ga*1e2;
ROGa = RO.Ga*1e2;
PEGa_integer = floor(PEGa); % ��������
ROGa_integer = floor(ROGa);

PEGa_fration = floor((PEGa - PEGa_integer)*1e3);
ROGa_fration = floor((ROGa - ROGa_integer)*1e3);
PEGa_amp = [num2str(PEGa_integer),'-',num2str(PEGa_fration)];
ROGa_amp = [num2str(ROGa_integer),'-',num2str(ROGa_fration)];

PE.name=[time_now,'PE_',num2str(round(PE.sw/1e3)),'k',num2str(round(PE.Te*1e3)),'ms'];
RO.name=[time_now,'RO_',num2str(round(RO.sw/1e3)),'k',num2str(round(RO.Te*1e3)),'ms'];

PE.name=[PE.name,'_Ga_',PEGa_amp,'_Smax_',num2str(PE.Smax),'_FOV_',num2str(PE.L*1e3),'_',num2str(PE.demandpoint)];
RO.name=[RO.name,'_Ga_',ROGa_amp,'_Smax_',num2str(PE.Smax),'_FOV_',num2str(RO.L*1e3),'_',num2str(PE.demandpoint)];
pe=ones(PE.demandpoint,2);
ro=ones(PE.demandpoint,2);

if length(PE.Gsam)==PE.demandpoint
    pe(:,1) = PE.Gsam;
    ro(:,1) = RO.Gsam;
end

if  length(PE.Gsam)<PE.demandpoint
     pe(end-length(PE.Gsam)+1:end,1)=PE.Gsam;
     ro(end-length(RO.Gsam)+1:end,1)=RO.Gsam;
     pe(1:end-length(PE.Gsam),1)=0;
     ro(1:end-length(RO.Gsam),1)=0;
end
    

% pe=ones(PE.demandpoint,2);
% pe(1:length(PE.Gsam),1)=PE.Gsam;
% ro=ones(PE.demandpoint,2);
% ro(1:length(RO.Gsam),1)=RO.Gsam;
% if length(PE.Gsam)<PE.demandpoint
%     pe(length(PE.Gsam)+1:end,1)=0;
%     ro(length(RO.Gsam)+1:end,1)=0;
% end
fid=fopen([dir2,PE.name,'.GRD'],'w+');
fidA=fopen('epipeǰ׺.txt','r');
DataA=fread(fidA);
fwrite(fid,DataA);
fprintf(fid,'\n');
[x,y]=size(pe);
for i=1:1:x
    for j=1:1:y
        fprintf(fid,'%-8d%-8d%',pe(i,j));
%         fprintf(fid,'\t');
    end
    fprintf(fid,'\n');
end
fclose(fid);
fid=fopen([dir2,RO.name,'.GRD'],'w+');
fidA=fopen('epipeǰ׺.txt','r');
DataA=fread(fidA);
fwrite(fid,DataA);
fprintf(fid,'\n');
[x,y]=size(ro);
for i=1:1:x
    for j=1:1:y
        fprintf(fid,'%-8d%-8d%',ro(i,j));
%         fprintf(fid,'\t');
    end
    fprintf(fid,'\n');
end
fclose(fid);

%----------------------���ݶ��ļ�������shapelib��------------------%
copyfile([dir2,RO.name,'.GRD'],Shapelib_dir);
copyfile([dir2,PE.name,'.GRD'],Shapelib_dir);
PE_Gsam = pe(:,1);
RO_Gsam = ro(:,1);
Smax = PE.Smax;
save([Shapelib_mat_dir,PE.name],'PE_Gsam','Smax');
save([Shapelib_mat_dir,RO.name],'RO_Gsam','Smax');
save([dir2,PE.name],'PE_Gsam','Smax');
save([dir2,RO.name],'RO_Gsam','Smax');
end