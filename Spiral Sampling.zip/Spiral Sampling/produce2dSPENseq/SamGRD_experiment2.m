function [PE,RO]=SamGRD_experiment2(PE,RO)
% �������������켣
% 2014��9��22�� 14:26:40

ECP=3*pi;	% each circle points
dt=4e-06;   % �������
t=0:dt:PE.Ta;
fs=1/dt;  % sampling rate
f=fs/ECP;     % signal frequency 
w=2*pi*f;

% T=200*dt;
% t=t.*sqrt(1+t/T);

PE.Gsam=w*t.*sin(w*t);  % ����������״
RO.Gsam=w*t.*cos(w*t);


Grandmax=32767; % �ݶ��ļ����ֵ
PE.Gsam=PE.Gsam/max(PE.Gsam)*Grandmax;  % �ݶȴ�С��һ��
RO.Gsam=RO.Gsam/max(RO.Gsam)*Grandmax;

% PE.Ge*PE.Te/2 = sum(PE.Gsam)/Grandmax*dt*PE.Ga   90Chirp
% RO.Ge*RO.Te = sum(RO.Gsam)/Grandmax*dt*RO.Ga    180Chirp

PE.diff = cumsum(PE.Gsam);
RO.diff = cumsum(RO.Gsam);

PE.Ga = (PE.Ge*PE.Te/2) / (max(abs(PE.diff))/Grandmax*dt);
RO.Ga = (RO.Ge*RO.Te) / (max(abs(RO.diff))/Grandmax*dt);


figure(1)
plot(PE.Gsam);title()

figure(3)
plot(PE.Gsam,RO.Gsam,'.');
title(['Gpa: ',num2str(PE.Ga),'  Gra:',num2str(RO.Ga)]);  
set(gcf,'outerposition',get(0,'screensize'));
saveas(gcf,[datadir,'trajectory'],'tiff');



end