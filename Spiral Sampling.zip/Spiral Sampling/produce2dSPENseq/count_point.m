function count=count_point(PEGsam_temp)
count=0;
for n=1:1:length(PEGsam_temp)-1
    if PEGsam_temp(n)*PEGsam_temp(n+1)<0
        count=count+1;
    end
end
end