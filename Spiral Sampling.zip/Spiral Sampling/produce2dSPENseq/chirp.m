function chirp(O,Te,name,qz)
%   qz ǰ׺

if nargin==3
    qz=1;
end

dt=1e-6; 
Oi=O/2;
R=-O/Te;
t=linspace(dt,(Te-dt),Te/dt);
amp=(1-cos(pi*t/Te).^40);
amp=amp/max(amp)*1024;
% wc=Oi+R*t;
phi=Oi*t+R*t.^2/2;
phi=angle(exp(1i*phi*2*pi))/pi*180;
for n=1:1:length(phi)
    if phi(n)<0
        phi(n)=phi(n)+360;
    end
end

rf=[phi;amp;ones(size(phi))]';
[x,y]=size(rf);
fid=fopen([name,'.RF'],'w+');
if qz~=0
    fidA=fopen('RFǰ׺.txt','r');
    DataA=fread(fidA);
    fwrite(fid,DataA);
    fprintf(fid,'\n');
end
for i=1:1:x
    for j=1:1:y
        fprintf(fid,'%-10.3f%\t',rf(i,j));
    end
    fprintf(fid,'\n');
end
fclose(fid);
end
