function C_new=Convert_2_constant_linear_velocity(C,fov)
% ���켣Cת��Ϊ�����ٵĹ켣
% by ����  2014��12��4�� 20:59:05
mean_lin_vel=max(abs(diff(C)));
% mean_lin_vel=0.2;
C_new=C(1);
num=length(C);
% factor = fov.^(-0.3); % supported field of view

% factor=linspace(1,1.5,length(C));
for n=2:1:num
    if abs(C(n)-C_new(end))>mean_lin_vel;%*factor(n)
        C_new=[C_new,C(n)];
    end
end

end