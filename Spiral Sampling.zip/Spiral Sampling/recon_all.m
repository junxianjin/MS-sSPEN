function recon_all(datadir)
% �ؽ�Ŀ¼�������е�����
% by ���� 2015��2��2�� 18:36:23

ifgems = 0;
ifepi = 0;
ifspen1d = 0;
ifspen2d = 0;
ifspenspiral = 1;


datadir=[datadir,'\'];
%----------------- gems reconstruction --------------------%
if ifgems ==1
disp('%----------------- gems reconstruction --------------------%')
temp=dir([datadir,'*gems*.fid']);
temp=struct2cell(temp)';
for n=1:1:size(temp,1)
    gems([datadir,temp{n}]);
    close all;
end
end
%----------------- epip reconstruction --------------------%
if ifepi ==1
disp('%----------------- epip reconstruction --------------------%')
temp=dir([datadir,'*epi*.fid']);
temp=struct2cell(temp)';
for n=1:1:size(temp,1)
    epip([datadir,temp{n}]);
    close all;
end
end

%----------------- SPEN1d reconstruction --------------------%
if ifspen1d == 1
disp('%----------------- SPEN1d reconstruction --------------------%')
temp=dir([datadir,'*SPEN1d*.fid']);
temp=struct2cell(temp)';
for n=1:1:size(temp,1)
    spen1d([datadir,temp{n}]);
    close all;
end
end
%----------------- SPEN2d reconstruction --------------------%
if ifspen2d == 1
disp('%----------------- SPEN2d reconstruction --------------------%')
temp=dir([datadir,'*spen2d*.fid']);
temp=struct2cell(temp)';
for n=1:1:size(temp,1)
    spen2d([datadir,temp{n}]);
    close all;
end
end

%----------------- SPENspiral reconstruction --------------------%
if ifspenspiral == 1
disp('%----------------- SPENspiral reconstruction --------------------%')
temp=dir([datadir,'*SPENspiral*.fid']);
temp=struct2cell(temp)';
for n=1:1:size(temp,1)
    spenspiral([datadir,temp{n}]);
    close all;
end
end
end