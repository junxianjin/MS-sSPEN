cc% ����������������
% by chenin 2014-12-8 19:50:28
clear all;close all;clc
addpath(strcat(pwd,'/produce2dSPENseq'));

%%
%-----------------------------------------
%==================ʱ���=================
%-----------------------------------------
date_now=datestr(now);
date_hour=num2str(hour(date_now));
date_minute=num2str(minute(date_now));
date_second=num2str(second(date_now));
time_now = [date,'_',date_hour,'_',date_minute,'_',date_second,'_'];
time_now2 = ['_',date_hour,'_',date_minute,'_',date_second];

factor_y=0.85;
factor_x=0.85;

ifsavedata = 1;
optimizeG = 1;
%%
%-----------------------------------------
%==================��������=================
%-----------------------------------------
param.filename='Spiral sampling';
param.sample='RatExp';
param.sample=[date,'_',param.sample];
% param.ExperimentMode='Simulation';
param.ExperimentMode='Experiment';
param.gama=42.58e6;
sampts=round(106*64);    % sampling points
dt = 4e-6;
Ta = dt*sampts;
RO.Ta = Ta;
PE.Ta = Ta;

%-------------PE----------%
PE.L=50e-3;     % mm
PE.sw=64e3;     % Hz
PE.Te=3e-3;   % s
PE.Ge=PE.sw/(param.gama*PE.L);
PE.chirp=1; % 1����90�� 2����180��
PE.rd=0;  % �����
PE.ta=dt;
% PE.step=128;
%-------------RO----------%
RO.L=50e-3;     % mm
RO.sw=32e3;     % Hz
RO.Te=3e-3;   % s
RO.Ge=RO.sw/(param.gama*RO.L);
RO.chirp=2; % 1����90�� 2����180��
RO.rd=0;  % �����
RO.ta=dt;
% RO.step=128;


%%
%-----------------------------------------
%===============��Ʋ����켣==============
%-----------------------------------------

%----------------�Ƚ��ٻ������---------------%
% ECP=80*pi;	% each circle points
% dt=4e-06;   % �������
% t=dt:dt:Ta;
% fs=1/dt;  % sampling rate
% f=fs/ECP;     % signal frequency 
% w=2*pi*f;
% 
% alpha=0.01;   %  alpha=0  ������    alpha=1 �Ƚ���
% % r = w*t;
% r = w*t./sqrt(alpha+(1-alpha)*t+eps);
% % theta = w*t./sqrt(alpha+(1-alpha)*t+eps);
% theta = w.*t;
% C = r.*exp(1i*theta);

Nitlv=20;
step=5;
PE.demandpoint=6996;
PE.Gsam = 0;
cal_number = 15;    % ���������
point_error = 50; % �����ĵ������
Nitlv_max=realmax;
PE_back=[];
RO_back=[];
while (abs(PE.demandpoint-length(PE.Gsam))~=0 && cal_number~=0)
%----------------���ܶ�---------------%
while (Nitlv+step)>=Nitlv_max % ��Nitlv����Nitlv_max��ʱ�򣬼���step
    step=step/2;
end
Nitlv=Nitlv+step;

disp('The current Nitlv');
disp(Nitlv);
disp('The number of remaining iterations');
disp(cal_number);

% radius = [0,0.35,0.43,0.83,1];  % normalized radius
% fov = [0,0.1,1,1,0.6]; % supported field of view
radius = [0,0.3,0.7,1];  % normalized radius
fov = [1,1,1,0.4]; % supported field of view
% radius = [0,1];  % normalized radius
% fov = [1,1]; % supported field of view
dr = 1/1e5;
r = 3*dr:dr:max(radius);
fov =  interp1(radius,fov,r,'linear');
dtheta = 2*pi*fov;
theta = cumsum(dtheta);
theta = theta/max(theta)*2*pi*Nitlv;
C = r.*exp(1i*theta);
% C=fliplr(C);
% C = [0,C];
% plot(real(C),imag(C),'.');


%-------------------------------------------------------------%
% �Թ켣���и�ֵ
% PE.Ge*PE.Te/2 = PE.C   90Chirp
% RO.Ge*RO.Te = RO.C    180Chirp
%-------------------------------------------------------------%
gama = 4.258;
PE.C = real(C)/max(abs(real(C)));
RO.C = imag(C)/max(abs(imag(C)));
PE.C = gama*PE.C*PE.Ge*PE.Te/2*1e5*factor_y;   % ��һ��
RO.C = gama*RO.C*RO.Ge*RO.Te*1e5*factor_x;
C = (PE.C + 1i*RO.C);
% C = fliplr(C);
% C=Convert_2_constant_linear_velocity(C,fov);
% num=round(length(C)*0.95);
% C=C(1:num);
C=[0,C];
figure(1)
plot(C,'.');
title(['Point:',num2str(length(C)),' Equivalent Point:',num2str(round(sqrt(length(C)))),' Circle:',num2str(count_point(PE.C))]);  
axis([-max(abs(real(C)))*1.2 max(abs(real(C)))*1.2  -max(abs(imag(C)))*1.2  max(abs(imag(C)))*1.2])

%%
if optimizeG==1
%-------------------------------------
%===============Ӳ��Լ��==============
%-------------------------------------
Gmax = 22;  % Gauss ms cm
Smax = 110;

[C,time,g,s,k, phi, sta, stb] = minTimeGradient(C, 0, Gmax, Gmax, Smax,4e-3,0);

PE.Gsam = real(g)/100;
RO.Gsam = imag(g)/100;
PE.Ga = max(abs(PE.Gsam));
RO.Ga = max(abs(RO.Gsam));
RO.Ta = RO.ta*length(RO.Gsam);
PE.Ta = PE.ta*length(PE.Gsam);
PE.Smax = Smax;
RO.Smax = Smax;

if length(PE.Gsam)<PE.demandpoint
    PE_back=PE; % ����PE��RO
    RO_back=RO;
end

if length(PE.Gsam)>PE.demandpoint
   Nitlv_max = Nitlv; % ��ֵ����Nitlv
   Nitlv = Nitlv - step;
   step = step/2;
   if isempty(PE_back)~=1
       PE=PE_back;  % �ָ�PE��RO
       RO=RO_back;
   end
end


cal_number = cal_number-1;

if PE.demandpoint>=length(PE.Gsam) && PE.demandpoint-length(PE.Gsam)<point_error
    cal_number = 0;
    disp('---------------------------------------------------------')
    disp('Reached the allowable error range. Iteration is terminated');
    disp('---------------------------------------------------------')
end

end
end

PE.Nitlv=Nitlv;

figure(1)
plot(PE.Gsam);title(['Smax ',num2str(max(abs(diff(PE.Gsam)))/dt),'Gmax:' num2str(PE.Ga)])
axis([1 length(PE.Gsam)  -PE.Ga*1.2  PE.Ga*1.2])

figure(2)
plot(RO.Gsam);title(['Smax ',num2str(max(abs(diff(RO.Gsam)))/dt),  'Gmax:' num2str(RO.Ga)])
axis([1 length(RO.Gsam)  -RO.Ga*1.2  RO.Ga*1.2])

figure(3)
plot(cumsum(PE.Gsam*dt*param.gama),cumsum(RO.Gsam*dt*param.gama),'.');
title(['Point:',num2str(length(RO.Gsam)), '  Circle:',num2str(PE.Nitlv)]);  
% set(gcf,'outerposition',get(0,'screensize'));
axis([-max(abs(real(C*1e2)))*1.2 max(abs(real(C*1e2)))*1.2  -max(abs(imag(C*1e2)))*1.2  max(abs(imag(C*1e2)))*1.2])

imshow_energy(PE,RO)

if ifsavedata==1 && optimizeG==1
%%
%-----------------------------------------
%===============�������ɳ���==============
%-----------------------------------------
datadir=['E:\Experiment Original Data\',param.filename,'\',param.ExperimentMode,'\',param.sample,'\',num2str(round(PE.sw/1e3)),'k',num2str(round(PE.Te*1e3)),...
    'ms_',num2str(round(RO.sw/1e3)),'k',num2str(round(RO.Te*1e3)),'ms_Lx',num2str(RO.L*1e3),'mm_Ly',num2str(PE.L*1e3),'mm_sampts_',num2str(length(RO.Gsam)),'_Gmax_',num2str(round(Gmax)),'_Smax_',num2str(round(Smax)),time_now2];
produce_Spiral_seq(PE,RO,datadir,time_now);

copyfile([mfilename,'.m'],[datadir,'\']);
copyfile('E:\Data Processing\toolbox\model\1d.sav',[datadir,'\']);
copyfile('E:\Data Processing\toolbox\model\2d_45mm.par',[datadir,'\']);
copyfile('E:\Data Processing\toolbox\model\Spiral_model.M0',[datadir,'\']);
end