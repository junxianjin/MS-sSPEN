% ��ά�ռ���봦������
% by ľľ 2013��3��15��11:06:15
ini;
addpath(strcat(pwd,'/myCS'));
addpath(strcat(pwd,'/utils'));
addpath(strcat(pwd,'/rwt-master'));
Shapelib_mat_dir = 'E:\Experiment Original Data\Spiral sampling\Shapelib\Mat\';
gama=2.6752e8;
%%
%-----------------------------------------
%==================ʱ���=================
%-----------------------------------------
date_now=datestr(now);
date_hour=num2str(hour(date_now));
date_minute=num2str(minute(date_now));
date_second=num2str(second(date_now));
time=['_',date_hour,'_',date_minute,'_',date_second];

%%
%-----------------------------------------
%==================��������=================
%-----------------------------------------
param.Spiral = 0; % �ж��Ƿ������������ǵȼ��   0�ȼ��  1����
param.CS=0;
param.De_con=1;
param.correct=0;% ������λУ��
param.imshow = 0;

param.savedate=1;
param.simu=1;
param.iteration=8;
param.num=512;
%%
%------------------------------------%
%----------------��������------------%
%------------------------------------%
if param.simu==0
    param.datadir='E:\Experiment Original Data\Spiral sampling\Experiment\16-Jan-2015_Phantom\16-Jan-2015_10_51_56_RO_32k3ms_Ga_16-999_Smax_85_FOV_40_6996_SPEN_Spiral_tpwrp=58.fid';
    [RE,IM,NP,NB,NT,HDR]=load_fid(param.datadir);
    param.st=RE+1i*IM;
    Para=getpar(param.datadir,'p1_bw','pw1','lpe','pepat','gradpe','pp_bw','pp','lro','ropat','gradro');
    PE.L = Para.lpe*1e-2;
    PE.sw = Para.p1_bw;
    PE.Te = Para.pw1;
    PE.Ga = Para.gradpe*1e-2;
    PE.pepat = Para.pepat;
    PE.Ge=-PE.sw/(gama*PE.L)*2*pi;
    PE.chirp=1; % 1����90�� 2����180��
    
    RO.L = Para.lro*1e-2;
    RO.sw = Para.pp_bw;
    RO.Te = Para.pp;
    RO.Ga = Para.gradro*1e-2;
    RO.pepat = Para.ropat;
    RO.Ge = RO.sw/(gama*RO.L)*2*pi;
    RO.chirp=2;
    
    load([Shapelib_mat_dir,PE.pepat]);
    load([Shapelib_mat_dir,RO.pepat]);
    
    temp = 1;
    while(PE_Gsam(temp)==0 && RO_Gsam(temp)==0)
        temp = temp+1;
    end
    
    PE.Gsam = PE_Gsam(temp:end);
    RO.Gsam = RO_Gsam(temp:end);
    param.st = param.st(temp:end);

    param.datadir=[param.datadir,'\'];
    
else 
    param.datadir='E:\Experiment Original Data\Spiral sampling\Simulation\05-Sep-2015_DemonstrationDifferentTrajectory_paper\Cartesian_32k1ms';
    param.datadir=[param.datadir,'\'];
    name='temp_SpiralPhantom_new';
    temp=dir([param.datadir,'param.mat']);
    temp=struct2cell(temp)';
    load([param.datadir,temp{1}]);  % ��������
    param.st=readtempccb2D([param.datadir,name,'.ccb'],PE,RO);   % ��������

end

if param.savedate==1
    param.savedatadir=[param.datadir,'\',date,'_',date_hour,'_',date_minute,'_',date_second];
    mkdir(param.savedatadir);
    copyfile([mfilename,'.m'],[param.savedatadir,'\']);
end
figure;
plot(abs(param.st));title(num2str(length(param.st)))


PE.phasefactor=1;
RO.phasefactor=1;
% factor=0.06;
% PE.phasefactor=1+factor;
% RO.phasefactor=1-factor;
% param.sign2=1;


if param.simu==0
    PE.Ge = PE.Ge;
    RO.Ge = RO.Ge;
    PE.Ga = PE.Ga;
    RO.Ga = PE.Ga;
end

param.gama=gama;
PE_bk=PE;
RO_bk=RO;
param_bk=param;
%%
%------------------------------------%
%----------------�����ؽ�------------%
%------------------------------------%
if param.De_con==1
    param = param_bk;
    PE = PE_bk;
    RO = RO_bk;
    SPEN2D_calPmatrix
    Pr=Pmatrix2d(PE.P_matrix,RO.P_matrix);
    roh=Pr'*param.st;
    param.method='De-con';
    postprocess_2D_SPEN(roh,PE,RO,param)
end


if param.CS==1
    param = param_bk;
    PE = PE_bk;
    RO = RO_bk;
    SPEN2D_calPmatrix
    xfmWeight = 1e-3;
    TVWeight = 1e-3;
    Itnlim=8;
%     XFM = Wavelet('Daubechies',6,6);
%     XFM = TIDCT(6,4);
    XFM = 1;
    myCS_2D
    param.method='CS';
    postprocess_2D_SPEN(roh,PE,RO,param)
end


