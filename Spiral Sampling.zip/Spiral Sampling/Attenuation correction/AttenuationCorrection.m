ini;
load('Simulation\PE512'); 
load('Simulation\RO512'); 
Pr=Pmatrix2d(PE.P_matrix,RO.P_matrix);
param.st_correct=double(imread('Simulation\Spiral_model_sharp.tiff'));
BlurImage = fliplr(imrotate(Pr*param.st_correct,-90));
figure;imshow(abs(BlurImage),[]);


load('Simulation\PE256'); 
load('Simulation\RO256'); 
num=length(PE.Gsam);
Ta=4e-6;

x = repmat(linspace(-RO.L/2,RO.L/2,size(BlurImage,1)),[size(BlurImage,2),1]);
y = repmat(linspace(-PE.L/2,PE.L/2,size(BlurImage,2))',[1,size(BlurImage,1)]);
BlurImage = BlurImage(:);
x = x(:);
y = y(:);

maxGrandient=max(PE.Gsam);
PE.Gsam=PE.Gsam/max(abs(PE.Gsam))*PE.Ga;
RO.Gsam=RO.Gsam/max(abs(RO.Gsam))*RO.Ga;

PE.intGacq=cumsum(PE.Gsam)*Ta;
RO.intGacq=cumsum(RO.Gsam)*Ta;

param.intGacqy=PE.intGacq;
param.intGacqx=RO.intGacq;

PE.y=PE.intGacq*PE.L/(PE.Ge*PE.Te*PE.chirp);
RO.x=RO.intGacq*RO.L/(RO.Ge*RO.Te*RO.chirp);

param.st = griddata(x,y,BlurImage,RO.x,PE.y);
gridimshow(param,PE,RO);
Tacq = linspace(0,6996*Ta,length(PE.y))';

data_matrix = [param.st,RO.x,PE.y,Tacq];

record=[];
for n=1:1:length(data_matrix);
    if (RO.x(n)>RO.L/10 || RO.x(n)<-RO.L/10) || PE.y(n)>0;
        record=[record,n];
    end
end
data_matrix(record,:)=[];
data_matrix(1:500,:)=[];
data_matrix(700:end,:)=[];
data = data_matrix(:,1);
time = data_matrix(:,4);
% data = abs(data(500:80:3145));
data = data/max(data);
% time = time(500:80:3145);
plot(time*1e3,data,'.','LineWidth',1.5,'MarkerSize',9);hold on

T2 = fminsearch(@(x)norm((x(1)*exp(-time/x(2))-data)),[1,0]);

x = (min(time):Ta:max(time))*1e3;
plot(x,T2(1)*exp(-x*1e-3/T2(2)),'r-','LineWidth',1.5,'MarkerSize',9)

xlabel('Time (ms)','FontName','Times New Roman','FontSize',28,'fontweight','b')
ylabel('Relative magnitude','FontName','Times New Roman','FontSize',28,'fontweight','b','Rotation',90)
axis([min(x*1.02),max(x*1.02),-0.01,1.05]);
set(gca,'FontName','Arial','FontSize',20,'fontweight','b','LineWidth',3,'GridLineStyle','--','TickDir','out')
set (gcf,'Position',[500,500,700*1.5,300*1.5], 'color','w')
% legend('Distortion trend')
saveas(gcf,'PFS.eps','psc2');
