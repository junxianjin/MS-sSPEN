ini;
load('Simulation\PE512'); 
load('Simulation\RO512'); 
Pr=Pmatrix2d(PE.P_matrix,RO.P_matrix);
param.st_correct=double(imread('Simulation\Spiral_model_sharp.tiff'));
% BlurImage = fliplr(imrotate(Pr*param.st_correct,-90));
BlurImage = Pr*param.st_correct;
param.st = BlurImage(1:3:end,1:3:end);
param.st = imresize(param.st,size(BlurImage));
imshow(abs(Pr'*param.st),[])