function [RE,IM]=grid_spiral_auto(xtrace,ytrace,Lx,Ly,st,xnum,ynum,flag,fov_change,sign)
xmin=min(xtrace);
xmax=max(xtrace);
ymin=min(ytrace);
ymax=max(ytrace);
rest=real(st);
imst=imag(st);
if fov_change==0
   fovx=xmax-xmin;
   fovy=ymax-ymin;
   dx=fovx/(xnum-1);
   dy=fovy/(ynum-1);
   xgrid=xmin:dx:xmax;
   ygrid=ymin:dy:ymax;
else
   fovx=Lx;
   fovy=Ly;
   dx=fovx/(xnum-1);
   dy=fovy/(ynum-1);
   xgrid=-fovx/2:dx:fovx/2;
   ygrid=-fovy/2:dy:fovy/2;
end
% ygrid=ygrid';
% xgrid=xgrid';
if sign==1
   [XI,YI]=meshgrid(xgrid,ygrid);
else
   [YI,XI]=meshgrid(xgrid,ygrid);
end
re=griddata(xtrace,ytrace,rest,XI,YI,flag);
im=griddata(xtrace,ytrace,imst,XI,YI,flag);
[numy numx]=size(re);
for y=1:numy
    for x=1:numx
        if isnan(re(y,x))
            re(y,x)=0;
        end
        if isnan(im(y,x))
            im(y,x)=0;
        end
    end
end
RE=re;
IM=im;
% re=TriScatteredInterp(xtrace,ytrace,rest);
% im=TriScatteredInterp(xtrace,ytrace,imst);

clear xmin;
clear xmax;
clear ymin;
clear ymax;
clear rest;
clear imst;
clear fovx;
clear fovy;
clear dx;
clear dy;
clear xgrid;
clear ygrid;
clear re;
clear im;
clear numy;
clear numx;
% clear XI;
% clear YI;