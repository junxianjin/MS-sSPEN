function [t_map]=map_t(xtrace,ytrace,st,xnum,ynum,Lx,Ly,flag,sign)
xmin=-Lx/2;
xmax=Lx/2;
ymin=-Ly/2;
ymax=Ly/2;
fovx=xmax-xmin;
fovy=ymax-ymin;
dx=fovx/(xnum-1);
dy=fovy/(ynum-1);
xgrid=xmin:dx:xmax;
ygrid=ymin:dy:ymax;
% ygrid=ygrid';
% xgrid=xgrid';
if sign==1
   [XI,YI]=meshgrid(xgrid,ygrid);
else
   [YI,XI]=meshgrid(xgrid,ygrid);
end
t_map=griddata(xtrace,ytrace,st,XI,YI,flag);
[numy numx]=size(t_map);
for y=1:numy
    for x=1:numx
        if isnan(t_map(y,x))
            t_map(y,x)=st(1);
        end
    end
end
% re=TriScatteredInterp(xtrace,ytrace,rest);
% im=TriScatteredInterp(xtrace,ytrace,imst);

clear xmin;
clear xmax;
clear ymin;
clear ymax;
clear fovx;
clear fovy;
clear dx;
clear dy;
clear xgrid;
clear ygrid;
clear numy;
clear numx;
% clear XI;
% clear YI;