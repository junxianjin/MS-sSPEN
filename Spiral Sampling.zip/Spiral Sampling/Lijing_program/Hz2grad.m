function [gimx,gimy,gimxy,gimx2,gimy2]=Hz2grad(fx,fy,fxy,fx2,fy2,Lx,Ly)
gama=2.675200e8;
gimx=2*pi*fx/(gama*Lx);
gimy=2*pi*fy/(gama*Ly);
gimxy=2*pi*fxy/(gama*Lx*Ly);
gimx2=2*pi*fx2/(gama*Lx*Lx);
gimy2=2*pi*fy2/(gama*Ly*Ly);