function [pha_correct]=correct(prescan,num,fill_number)
[numy numx]=size(prescan);
base=fft(prescan(num,:),fill_number);
base=fftshift(base);
base_pha=angle(base);
for y=1:numy
    current_fid=prescan(y,:);
    current_fft=fft(current_fid,fill_number);
    current_fft=fftshift(current_fft);
    current_pha=angle(current_fft);
    pha_correct(y,:)=base_pha-current_pha;
end
clear numy;
clear numx;
clear base;
clear base_pha;
clear current_fid;
clear current_fft;
clear current_pha;


    
