function [trace_new]=correct_180(trace,Gexc,Texc,Lx,acqrate,Gimx,sign_sx)
number=length(trace);
T=number*acqrate;
t=acqrate:acqrate:T;
t=t';
basex=Lx*Gimx/(2*Gexc*Texc);
trace_new=trace+sign_sx*basex.*t;
clear T;
clear t;
clear number;
