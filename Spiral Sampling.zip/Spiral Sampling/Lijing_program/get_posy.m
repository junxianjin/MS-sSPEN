function [position,L]=get_posy(pe_grad,Ly,Gexc,Texc,Gacq,step_point,acqrate,time,sign)
number=length(pe_grad);
grad=pe_grad;
MAX=max(grad);
grad=grad*Gacq/MAX;
sum=0;
for x=1:number
    sum=sum+grad(x)*step_point*acqrate;
end
sum=abs(sum);
Lyy=Ly*abs(sum/(time*Gexc*Texc));
pos_step=zeros(number*step_point,1);
sum_steps=0;
grad=abs(grad);
for x_pos=1:number
    for step=1:step_point
        current=grad(x_pos)*acqrate;
        current_step=current/sum;
        sum_steps=sum_steps+current_step;
        pos_step((x_pos-1)*step_point+step)=sum_steps;
    end
end
position=zeros(number*step_point,1);
for xx=1:number*step_point
    position(xx)=sign*(-1/2+pos_step(xx))*Lyy;
end
L=Lyy;
clear number;
clear xx;
clear step_point;
clear pos_step;
clear sum_steps;
clear grad;
clear MAX;
clear sum;
clear current_step;
clear current;
        
        




    

