function [epiro]=enlarge(epi,times)
number=length(epi);
epiro=zeros(number*times,1);
for x=1:number
    for y=1:times
        epiro((x-1)*times+y)=epi(x);
    end
end
clear number;
clear epi;
clear times;
