function [FID]=D2shift(FID)
[numy,numx]=size(FID);
for y=1:1:numy
    if mod(y,2)==0
        for x=1:1:numx/2
        tt=FID(y,x);
        FID(y,x)=FID(y,numx-x+1);
        FID(y,numx-x+1)=tt;
        end
    end
end
clear numy;
clear numx;
clear tt;