function [pos,fov]=find_trace_all1(epiro,sy,Gexc,Texc,Lx,Gacq,Gror,acqrate,Omega,gimx,gimy,gimxy,gimx2,TE,signx,sign_sx,sign_sy,sign_xy,sign_xx,times)
gama=2.675200e8;
Gexc=abs(Gexc);
Gacq=abs(Gacq);
number=length(epiro);
format long;
tt=acqrate;
MAX=max(abs(epiro));
grad=Gacq.*epiro./MAX;
grad_sum=zeros(number,1);
sum_grad=Gror;
for y=1:1:number
    format long;
    sum_grad=sum_grad+grad(y,1);
    format long;
    grad_sum(y)=sum_grad;
end
format long;
base_grad=gama*grad_sum.*tt;
%%
base0=2*Omega*Texc/(Lx*times);
base_x=zeros(number,1);
base_y=zeros(number,1);
base_xy=zeros(number,1);
base_xx=zeros(number,1);
for yy=1:1:number
    format long;
    current_t=yy*tt+TE;
    format long;
    current_pos=sy(yy);
    format long;
    base_x(yy)=gama*gimx*current_t;
    format long;
    base_xy(yy)=gama*gimxy*current_t*current_pos;
    format long;
    base_y(yy)=2*gama*gimy*Texc*current_pos/(Lx*times);
    format long;
    base_xx(yy)=gama*gimx2*current_t;
end
format long;
base_x=sign_sx.*base_x;
format long;
base_y=sign_sy.*(base0+base_y);
format long;
base_xy=sign_xy.*base_xy;
format long;
base_xx=sign_xx.*base_xx;
format long;
base_exc=gama*(Gexc+2*gimx)*Texc/(times*Lx);
format long;
pos=signx.*(base_grad+base_x+base_xy+base_y)./(2*(base_exc+base_xx));
MAX_fov=max(pos);
MIN_fov=min(pos);
fov=MAX_fov-MIN_fov;
%%%%
clear Gexc;
clear Gacq;
clear number;
clear base_exc;
clear base_xx;
clear base_xy;
clear base_x;
clear base_y;
clear grad_sum;
clear grad;
clear yy;
clear tt;
clear base0;
clear MAX;




    

