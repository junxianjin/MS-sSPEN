function [pos1d,pos2d,L]=get_posy_vs(pe,numy,Gexc,Texc,Ly,Gacq,acqrate,step_point,sign)
number=length(pe);
pe=abs(pe);
ave=mean(pe);
grad=pe/max(pe);
grad=abs(grad*Gacq);
sum=0;
for y=1:number
    sum=sum+grad(y)*acqrate*step_point;
end
L=Ly*abs((sum/(Gexc*Texc)));
flat_step=L/(number*step_point);
grad_flat=ones(number,1)*ave;
format long;
pos_step=zeros(number*step_point,1);
for y=1:number
    for step=1:step_point
        if pe(y)==0
        pos_step((y-1)*step_point+step)=0;
        else
        pos_step((y-1)*step_point+step)=flat_step*pe(y)/grad_flat(y);
        end
    end
end
format long
posd=zeros(number*step_point,1);
format long;
sum_pos=0;
format long;
posa=zeros(number*step_point,1);
for y=1:number*step_point;
    sum_pos=sum_pos+pos_step(y);
    posa(y)=sum_pos;
end   
for y=1:number*step_point
    posd(y)=sign*(-L/2+posa(y));
end
format long;
pos1d=posd;
numx=round(number*step_point/numy);
format long;
pos2d_temp=zeros(numy,numx);
format long;
for y=1:numy
    for x=1:numx
        pos2d_temp(y,x)=pos1d((y-1)*numx+x);
    end
end
format long;
pos2d=pos2d_temp(:,1:numx-step_point);
clear x;
clear y;
clear pos2d_temp;
clear numx;
clear numy;
clear ave;
clear number;
clear pos_step;
clear grad_flat;
clear flat_step;
clear sum;
clear grad;

        





