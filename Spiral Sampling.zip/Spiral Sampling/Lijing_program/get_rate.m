function [rate1]=get_rate(map2d,posx,posy,diffx,diffy)
[numbery numberx]=size(map2d);
rx=round((diffx/2));
ry=round(diffy/2);
data0=map2d(posy,posx);
beginx=posx-rx;
beginy=posy-ry;
endx=posx+rx;
endy=posy+rx;
if beginx<1
    beginx=1;
end
if beginy<1;
    beginy=1;
end
if endx>numberx
    endx=numberx;
end
if endy>numbery
    endy=numbery;
end
sum_data=0;
ave=0;
for y=beginy:1:endy
    for x=beginx:1:endx
        ave=ave+1;
        current=map2d(y,x);
        current_dif=abs(current-data0);
        sum_data=sum_data+current_dif;
    end
end
rate1=sum_data/ave;
clear rx;
clear ry;
clear beginx;
clear beginy;
clear endx;
clear endy;
clear ave;
clear sum_data;
clear data0;
clear endx;
clear endy;


            
            

        
        
