function [sxx,flat]=match_xtrace(sx,numx,numy)
num=length(sx);
number=numx*numy;
sxx=zeros(number,1);
if num==numx
    for y=1:numy
        if mod(y,2)==0
            for x=1:numx
            sxx((y-1)*numx+x)=sx(numx-x+1);
            end
        else
            for x=1:numx
            sxx((y-1)*numx+x)=sx(x);
            end
        end
    end
    flat=1;
            
        
else
    flat=0;
end
clear x;
clear y;
clear num;
clear number;
