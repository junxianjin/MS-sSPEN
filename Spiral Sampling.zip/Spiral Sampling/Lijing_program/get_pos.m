function [position,L]=get_pos(epiro,Lx,Gexc,Texc,Gacq,step_point,acqrate,sign)
number=length(epiro);
count=1;
for x=1:number
    if epiro(x)~=0
        count=count+1;
    else
        break;
    end
end
grad=epiro(1:count);
MAX=max(grad);
grad=grad*Gacq/MAX;
sum=0;
for x=1:count
    sum=sum+grad(x)*step_point*acqrate;
end
sum=abs(sum);
Lxx=Lx*abs(sum/(2*Gexc*Texc));
pos_step=zeros(count*step_point,1);
sum_steps=0;
grad=abs(grad);
for x_pos=1:count
    for step=1:step_point
        current=grad(x_pos)*acqrate;
        current_step=current/sum;
        sum_steps=sum_steps+current_step;
        pos_step((x_pos-1)*step_point+step)=sum_steps;
    end
end
position=zeros(count*step_point,1);
for xx=1:count*step_point
    position(xx)=sign*(-1/2+pos_step(xx))*Lxx;
end
L=Lxx;
clear number;
clear xx;
clear count;
clear step_point;
clear pos_step;
clear sum_steps;
clear grad;
clear MAX;
clear sum;
clear current_step;
clear current;
        
        




    

