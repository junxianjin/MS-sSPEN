function [lxy]=lxy2d(st,base_num,Gexcx,Gexcy,Texcx,Texcy,Lx,Ly,sign)
gama=2.67e8;
number=length(st);
y_step=Ly/number;
x_step=Lx/base_num;
lxy=zeros(number,1);
numy=round(number/base_num);
numx=base_num;
for y=1:numy
    for x=1:numx
    if mod(y,2)==1
       current_x=-Lx/2+(x-1)*x_step; 
    else
       current_x=Lx/2-(x-1)*x_step;
    end
    current_numy=(y-1)*numx+x;
    current_y=-Ly/2+(current_numy-1)*y_step;
    ther=-(gama*Gexcx*Texcx/Lx)*current_x*current_x+(gama*Gexcy*Texcy/Ly)*current_y*current_y;
    ther=sign*(ther);
    re=cos(ther);
    im=sin(ther);
    current_lzre=real(st(current_numy))*re+imag(st(current_numy))*im;
    current_lzim=imag(st(current_numy))*re-real(st(current_numy))*im;
    lxy(current_numy)=current_lzre+1j*current_lzim;
    end
end
clear numx;
clear numy;
clear current_lzre;
clear current_lzim;
clear current_x;
clear current_y;
clear current_numy;
clear re;
clear im;
clear x_step;
clear y_step;
