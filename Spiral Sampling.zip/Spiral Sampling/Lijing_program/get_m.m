function [mx]=get_m(A,L,num,expand_num,inter_num,cc)
number=expand_num*num;
z_step=cc*L/(expand_num*num);
z_step_step=z_step/inter_num;
mx=zeros(number,1);
for x=0:1:number-1
    current_z=-cc*L/2+x*z_step;
    re=0;im=0;
    for y=0:1:inter_num
        current_z_z=current_z+(y-inter_num/2)*z_step_step;
        ther1=A*current_z_z*current_z_z/2;
        re=re+cos(ther1);
        im=im+sin(ther1);
    end
    current_re=re/inter_num;
    current_im=im/inter_num;
    mx(x+1)=current_re+current_im*1j;
end
clear z_step;
clear z_step_step;
clear current_z;
clear number;
clear re;
clear im;
clear current_re;
clear current_im;
clear ther1;

