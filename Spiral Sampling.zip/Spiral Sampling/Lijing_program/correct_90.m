function [trace_new]=correct_90(trace,Gexc,Texc,Lx,acqrate,Gimx,sign_sy)
number=length(trace);
T=number*acqrate;
t=acqrate:acqrate:T;
t=t';
basex=Lx*Gimx/(Gexc*Texc);
trace_new=trace+sign_sy*basex.*t;
clear T;
clear t;
clear number;
