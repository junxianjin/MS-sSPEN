function [ly]=depha_pos(st,Gexc,Texc,L,posth,pos,time,sign,flag)
Gexc=abs(Gexc);
gama=2.6752e8;
num=length(st);
ly=zeros(num,1);
if flag=='x'
    current_pos1d=pos(posth,:);
end
if flag=='y'
    current_pos1d=pos(:,posth);
end
for x=1:num
    current_pos=current_pos1d(num-x+1);
    ther=sign*(gama*Gexc*Texc/(L*time))*current_pos*current_pos;
    re=cos(ther);
    im=sin(ther);
%     current_lzre=real(st(num-x+1))*re+imag(st(num-x+1))*im;
%     current_lzim=imag(st(num-x+1))*re-real(st(num-x+1))*im;
    current_lzre=real(st(x))*re+imag(st(x))*im;
    current_lzim=imag(st(x))*re-real(st(x))*im;
    ly(x)=current_lzre+1j*current_lzim;
end
clear num;
clear step;
clear ther;
clear re;
clear im;
clear current_lzre;
clear current_lzim;