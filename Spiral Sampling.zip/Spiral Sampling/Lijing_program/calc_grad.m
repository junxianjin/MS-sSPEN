function [Gror,MAX]=calc_grad(epiro,Gacq_x,sign)
number=length(epiro);
Gacq_x=abs(Gacq_x);
epiro=abs(epiro);
MAX=max(abs(epiro));
sum_grad=0;
grad=Gacq_x*epiro/MAX;
for y=1:1:number
    sum_grad=sum_grad+grad(y);
end
Gror=sum_grad*sign;
clear epiro;
clear sum_grad;
clear grad;
clear number;
