function [map1,posx,posy,nth]=del_zero(map,pos)
number=length(map);
nth=0;
for x=1:number
    if map(x)~=0
        nth=nth+1;
    end
end
map1=map(1:nth);
posx=round(real(pos(1:nth)));
posy=round(imag(pos(1:nth)));
clear number;

