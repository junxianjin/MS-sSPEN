function [data]=shift(FID,numx,numy)
for x=1:numx
    if mod(x,2)==0
        FID(x,:)=circshift(FID(x,:),[0 -1]);
    end
end
data=FID;
