function [pos,pos2d]=position_adj(position,numy,step_point)
number=length(position);
numx=round(number/numy);
poss=zeros(numy,numx);
for y=1:numy
    for x=1:numx
        poss(y,x)=position((y-1)*numx+x);
    end
end
numx_cut=numx-step_point;
pos_cut=poss(:,1:numx_cut);
pos=zeros(numy*numx_cut,1);
for y=1:numy
    for x=1:numx_cut
        pos((y-1)*numx_cut+x)=pos_cut(y,x);
    end
end
pos2d=pos_cut;
clear number;
clear numx;
clear poss;
clear numx_cut;
clear poss_cut;
       
