function [data]=combine_data(odd_data,even_data)
[numyo numxo]=size(odd_data);
[numye numxe]=size(even_data);
number=numyo+numye;
numx=numxo;
if numxo~=numxe
   data=zeros(number,numx);
else
    data=zeros(number,numx);
    num_even=0;
    num_odd=0;
    for y=1:1:number
        if mod(y,2)==0
            num_even=num_even+1;
            data(y,:)=even_data(num_even,:);
        end
        if mod(y,2)==1
            num_odd=num_odd+1;
            data(y,:)=odd_data(num_odd,:);
        end
    end
end
clear number;
clear numx;
clear numxo;
clear numyo;
clear numye;
clear numxe;
clear num_even;
clear num_odd;
