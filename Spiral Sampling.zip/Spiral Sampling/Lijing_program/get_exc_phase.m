function [pha_exc]=get_exc_phase(Gexc,Texc,Ly,sign,num)
y_step=Ly/num;
pha_exc=zeros(num,1);
for x=1:1:num
    y_pos=sign*(-Ly/2+(x-1)*y_step);
    ther=-gama*Gexc*Texc*y_pos.^2/2+gama*Gexc*Texc*y_pos/2-gama*Gexc*Texc*Ly/8-pi/2;
    pha_exc(x)=cos(ther)+1j*sin(ther);
end
    

     
        
        
