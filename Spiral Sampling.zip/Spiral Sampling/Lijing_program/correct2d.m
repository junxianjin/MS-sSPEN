function [pha]=correct2d(prescan,num)
[numy numx]=size(prescan);
base=prescan(num,:);
base_pha=angle(base);
for y=1:numy
    current=prescan(y,:);
    current_pha=angle(current);
    current_diff=base_pha-current_pha;
    pha(y,:)=current_diff;
end
clear base;
clear base_pha;
clear numy;
clear numx;
clear current;
clear current_pha;
clear current_diff;