function [phase]=get_pha(Ly,ini_position,numy,numx,Tro,gama,Gacq,sign,num)
y_step=Ly/numy;
y_step_step=y_step/numx;
y_step_d=y_step_step/num;
delta_t=Tro/numx;
phase=zeros(numy,numx);
for y=1:numy
    current_pos=ini_position+sign*(y-1)*y_step;
    for x=1:numx
        current_poss=current_pos+x*y_step_step;
        current=0;
        for z=1:num
            current_p=current_poss-y_step_step/2+(z-1)*y_step_d;
            current_t=x*delta_t;
            current=current+gama*Gacq*current_t*current_p;
        end
        phase(y,x)=current/num;
        
    end
end
