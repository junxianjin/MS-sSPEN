function [lxy]=smooth_phase_180_R(st,sx,sy,Gexc_x,Texc_x,Lx,Gexc_y,Texc_y,Ly,gama,sign)
Gexc_x=abs(Gexc_x);
Gexc_y=abs(Gexc_y);
Rx=gama*Gexc_x*Lx/Texc_x;
Ry=gama*Gexc_y*Ly/Texc_y;

num=length(sx);
lxy=zeros(num,1);
format long;
base_x=gama.^2*Gexc_x.^2/Rx;
format long;
base_y=gama.^2*Gexc_y.^2/Ry;
format long;
base_1x=gama*(Gexc_x)*Texc_x*Lx/4;
format long;
base_1y=gama*(Gexc_y)*Texc_y*Ly/4;
for x=1:num
    current_x=sx(x);
    current_y=sy(x);
    ther=sign*(-base_x*current_x.^2+base_y*current_y.^2+base_1x-base_1y);
    re=cos(ther);
    im=sin(ther);
    current_lzre=real(st(x))*re+imag(st(x))*im;
    current_lzim=imag(st(x))*re-real(st(x))*im;
    lxy(x)=current_lzre+1j*current_lzim;
end
clear re;
clear im;
clear current_x;
clear current_y;
clear ther;
clear num;
clear const_x;
clear const_y;
clear base_x;
clear base_y;
    