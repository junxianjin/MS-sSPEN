function [lxy]=get_lxy(st,x,y,R,Gexc,gama,sign)
num=length(x);
lxy=zeros(num,1);
for i=1:num
    current_x=x(i);
    current_y=y(i);
    ther=sign*gama.^2*Gexc.^2*(current_x.^2-current_y.^2)/R;
    re=cos(ther);
    im=sin(ther);
    current_lzre=real(st(i))*re+imag(st(i))*im;
    current_lzim=imag(st(i))*re-real(st(i))*im;
    lxy(i)=current_lzre+1j*current_lzim;
end
clear re;
clear im;
clear current_x;
clear current_y;
clear ther;
clear num;
    
    

