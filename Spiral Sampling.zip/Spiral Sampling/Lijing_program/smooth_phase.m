function [lxy]=smooth_phase(st,sx,sy,Gexc_x,Texc_x,Lx,Gexc_y,Texc_y,Ly,gimx,gimy,gama,sign)
Gexc_x=abs(Gexc_x);
Gexc_y=abs(Gexc_y);
num=length(sx);
lxy=zeros(num,1);
const_x=gama*(Gexc_x+gimx)*Texc_x*Lx/4;
const_y=gama*(Gexc_y+gimy)*Texc_y*Ly/8;
base_x=gama*(Gexc_x+gimx)*Texc_x/Lx;
base_y=gama*(Gexc_y+gimy)*Texc_y/(2*Ly);
for x=1:num
    current_x=sx(x);
    current_y=sy(x);
    ther=sign*(-const_y+const_x-base_x*current_x*current_x+base_y*current_y*current_y-pi/2);
    re=cos(ther);
    im=sin(ther);
    current_lzre=real(st(x))*re+imag(st(x))*im;
    current_lzim=imag(st(x))*re-real(st(x))*im;
    lxy(x)=current_lzre+1j*current_lzim;
end
clear re;
clear im;
clear current_x;
clear current_y;
clear ther;
clear num;
clear const_x;
clear const_y;
clear base_x;
clear base_y;
    