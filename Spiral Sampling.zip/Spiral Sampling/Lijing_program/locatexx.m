function [pos,fov_real]=locatexx(epiro,Gexc,Texc,fov,Gacq,acqrate,gim,TE,signy,sign_inh)
gama=2.675200e8;
Gexc=abs(Gexc);
Gacq=abs(Gacq);
number=length(epiro);
format long;
delat_t=acqrate;
MAX=max(epiro);
gradient=Gacq*epiro/MAX;
gradient_sum=zeros(number,1);
sum_grad=0;
for y=1:1:number
    format long;
    sum_grad=sum_grad+gradient(y,1);
    format long;
    gradient_sum(y)=sum_grad;
end
format long;
base_pos=gradient_sum.*delat_t/(Gexc*Texc+gim*Texc);
format long;
pos_current=-fov*(base_pos)/2;
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�������ڲ����ȳ��õ���Ӱ��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
format long;
base=gama*(Gexc+gim)*Texc;
format long;
pos_inh_TE=gama*gim*TE;
format long;
pos_inh=zeros(number,1);
for tt=1:1:number
    time_pos=tt*delat_t;
    format long;
    pos_inh(tt)=gama*gim*time_pos;
end
format long;
pos_inh=fov.*(pos_inh_TE-pos_inh)./(2*base);
pos_inh=sign_inh*pos_inh;
pos=signy*(pos_current+pos_inh);
MAX_fov=max(pos);
MIN_fov=min(pos);
fov_real=MAX_fov-MIN_fov;
clear number;
clear pos_inh_TE;
clear delat_t;
clear MAX;
clear gradient;
clear gradient_sum
clear sum_grad
clear pos_current
clear base
clear pos_inh
clear MAX_fov
clear MIN_fov
clear tt
clear y

