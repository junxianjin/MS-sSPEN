function [FID]=cut_FID(st,numy,numx,step_point)
fid=zeros(numy,numx);
for y=1:numy
    for x=1:numx
        fid(y,x)=st((y-1)*numx+x);
    end
end
FID=fid(:,1:numx-step_point);
numx=numx-step_point;
for y=1:numy
    if mod(y,2)==0
        for x=1:numx/2
            tt=FID(y,x);
            FID(y,x)=FID(y,numx-x+1);
            FID(y,numx-x+1)=tt;
        end
    end
end
clear fid;
clear numx;
clear numy;
clear step_point;
