function [ave]=std2d(x_begin,y_begin,x_width,y_width,st)
st_local=st(y_begin:y_begin+y_width-1,x_begin:x_begin+x_width-1);
signal=zeros(y_width*x_width,1);
for y=1:y_width
    for x=1:x_width
        signal((y-1)*x_width+x)=st_local(y,x);
    end
end
ave=std(signal);
clear x;
clear y;
clear signal;