function [sx_real]=find_trace_xy(sx,sy,Gexc,Texc_x,Texc_y,fov,gimxy,acqrate,TE,signxy,signxy_sx,timexy)
gama=2.675200e8;
number=length(sx);
Gexc=abs(Gexc);
delat_t=acqrate;
pos=zeros(number,1);
base=gama*Gexc*Texc_x*timexy;
for tt=1:1:number
    current_pos=sy(tt);
    current_t=delat_t*tt-TE+Texc_y/2;
    pos(tt)=gama*gimxy*current_t*current_pos;
end
pos=fov.*pos./base;
sx_real=signxy*(sx-signxy_sx*pos);
clear number;
clear delat_t;
clear base;
clear pos;

    
    
    
    
