function [lxy]=smooth_phase_180(st,sx,sy,Gexc_x,Texc_x,Lx,Gexc_y,Texc_y,Ly,gimx,gimy,gama,sign)
num=length(sx);
lxy=zeros(num,1);

base_x=gama*(Gexc_x+gimx)*Texc_x/Lx;
base_y=gama*(Gexc_y+gimy)*Texc_y/(Ly);
base_1x=gama*(Gexc_x+gimx)*Texc_x*Lx/4;
base_1y=gama*(Gexc_y+gimy)*Texc_y*Ly/4;
for x=1:num
    current_x=sx(x);
    current_y=sy(x);
    ther=sign*(-base_x*current_x*current_x+base_y*current_y*current_y+base_1x-base_1y);
    re=cos(ther);
    im=sin(ther);
    current_lzre=real(st(x))*re+imag(st(x))*im;
    current_lzim=imag(st(x))*re-real(st(x))*im;
    lxy(x)=current_lzre+1j*current_lzim;
end
clear re;
clear im;
clear current_x;
clear current_y;
clear ther;
clear num;
clear const_x;
clear const_y;
clear base_x;
clear base_y;
    