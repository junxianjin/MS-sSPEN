function [data]=D2Dshift(st,numx,numy,odd,even)
FID=zeros(numx,numy);
for x=1:numx
    for y=1:numy
        FID(x,y)=st((x-1)*numy+y);
    end
end
for x=1:numx
    if mod(x,2)==0
        for y=1:numy/2
            tt=FID(x,y);
            FID(x,y)=FID(x,numy-y+1);
            FID(x,numy-y+1)=tt;
        end
    end
end
for x=1:numx
    if mod(x,2)==0
        FID(x,:)=circshift(FID(x,:),[0 even]);
    else
        FID(x,:)=circshift(FID(x,:),[0 odd]);
    end
end
data=FID;
clear FID;
clear numx;
clear numy;