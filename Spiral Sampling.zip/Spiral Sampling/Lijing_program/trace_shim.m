function [pos,fov_real]=trace_shim(epiro,Gexc,Texc,fov,Gacq,acqrate,base_grad,sign,times)
gama=2.675200e8;
Gexc=abs(Gexc);
Gacq=abs(Gacq);
number=length(epiro);
format long;
delat_t=acqrate;
MAX=max(epiro);
gradient=Gacq*epiro/MAX;
gradient_sum=zeros(number,1);
sum_grad=base_grad;
for y=1:1:number
    format long;
    sum_grad=sum_grad+gradient(y,1);
    format long;
    gradient_sum(y)=sum_grad;
end
format long;
base_gradient=gama*gradient_sum.*delat_t;
%%
base=fov/(times*gama*Gexc*Texc);
pos=sign*(base*base_gradient);
MAX_fov=max(pos);
MIN_fov=min(pos);
fov_real=MAX_fov-MIN_fov;
clear number;
clear delat_t;
clear MAX;
clear gradient;
clear gradient_sum
clear sum_grad
clear base
clear base_gradient;
clear MAX_fov
clear MIN_fov
