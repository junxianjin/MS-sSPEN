function [line]=zuhe(st,x_begin,y_begin,x_width,y_width,data)
num_length=length(st);
st_local=data(y_begin:y_begin+y_width-1,x_begin:x_begin+x_width-1);
signal=zeros(y_width*x_width,1);
for y=1:y_width
    for x=1:x_width
        signal((y-1)*x_width+x,1)=st_local(y,x);
    end
end
if num_length==1
    line=signal;
else
    line=[st ;signal];
end
clear st_local;
clear signal;
clear y;
clear x;
