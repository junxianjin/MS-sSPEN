function [XI,YI]=grid_fov(xnum,ynum,Lx,Ly,sign)
xmin=-Lx/2;
xmax=Lx/2;
ymin=-Ly/2;
ymax=Ly/2;
fovx=xmax-xmin;
fovy=ymax-ymin;
dx=fovx/(xnum-1);
dy=fovy/(ynum-1);
xgrid=xmin:dx:xmax;
ygrid=ymin:dy:ymax;
% ygrid=ygrid';
% xgrid=xgrid';
if sign==1
   [XI,YI]=meshgrid(xgrid,ygrid);
else
   [YI,XI]=meshgrid(xgrid,ygrid);
end
clear xmin;
clear ymin;
clear xmax;
clear ymax;
clear fovx;
clear fovy;
clear dx;
clear dy;
clear xgrid;
clear ygrid;