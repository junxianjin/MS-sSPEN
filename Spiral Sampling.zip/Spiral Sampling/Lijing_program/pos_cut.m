function [sx]=pos_cut(sx,numxx,numx,numy,left,right,shift)
number=length(sx);
if number==numxx*numy
    [SX]=cut_FID(sx,numy,numxx,0);
    line=D2line(SX);
    [pos]=D2Dshift(line,numy,numxx,left,right);
    cut=numxx-numx;
    cut=round(cut/2);
    cut=cut+shift;
    pos1=pos(:,cut:cut+numx-1);
    sx=D2line(pos1);
else
    sx=0;
end
clear number;
clear line;
clear SX;
clear cut;
clear pos1;
clear pos;

    
    
