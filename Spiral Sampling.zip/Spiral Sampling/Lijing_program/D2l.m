function [data]=D2l(FID)
[numx,numy]=size(FID);
for y=1:numx
    for x=1:numy
        data((y-1)*numy+x)=FID(y,x);
    end
end
clear numx;
clear numy;