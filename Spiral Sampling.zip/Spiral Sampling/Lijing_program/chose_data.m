function [amp,pha]=chose_data(amp,pha,times)
[numy numx]=size(amp);
max_amp=max(max(amp));
base=times*max_amp;
for y=1:numy
    for x=1:numx
        if amp(y,x)<=base
            pha(y,x)=0;
        end
    end
end