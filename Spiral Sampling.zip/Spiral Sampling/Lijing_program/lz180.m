function [lz]=lz180(st,Oi,R,A,L,sign)
num=length(st);
z_step=L/num;
lz=zeros(num,1);
for x=1:num
    current_z=-L/2+(x-1)*z_step;
    ther=sign*(Oi*Oi/(R)+A*current_z*current_z/2);
    re=cos(ther);
    im=sin(ther);
    current_lzre=real(st(num-x+1))*re+imag(st(num-x+1))*im;
    current_lzim=imag(st(num-x+1))*re-real(st(num-x+1))*im;
    lz(x)=current_lzre+1j*current_lzim;
 
end
clear re;
clear im;
clear current_lzre;
clear current_lzim;
clear z_step;
clear num;
clear ther;

    
    