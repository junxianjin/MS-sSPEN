clear;clc;clf;
%%
[re im step s stpp]=load_fid('E:\Data Processing\Reconstruction program\2D random sampling\Lijing_program\phantom_axial90_frydman2d_dou_chirp_64k_4ms_chirp_8k_4ms_6464_7070_linear.fid');
% [epiro tt ii]=textread('grad\grad_file\epiro_rfov_linear.txt');
% [epipe tt ii]=textread('grad\grad_file\epipe_rfov_linear.txt');
[epiro tt]=textread('epiro.txt');
[epipe tt]=textread('epipe.txt');
[epiro_old tt]=textread('epiro.txt');
[epipe_old tt]=textread('epipe.txt');
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�ݶ��ļ���ʼ��%%%%%%%%%%%%%%%%%%%%%%
re=re';im=im';
st=re+1j*im;
[numy,numxst]=size(st);
st=st(numy/2+1:end,:);
base_num=102;
numxx=base_num;
epiro_base=(epiro_old(1:base_num));
epipe_base=(epipe_old(1:end));
epiro(1:base_num,1)=round(epiro(1:base_num));
times=1;
[epiro]=enlarge(epiro,times);
[epipe]=enlarge(epipe,times);
%%
%%%%%%%%%%%%%%%%%%%���ݽṹ��ʼ��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��־����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
recon=1;
%%
%----------���űȵĵ�λΪ��Hz/T-----------------%
gama=2.675200e8;
%----------�ݶȵĵ�λΪT/m-----------------%
timey=2;
timex=1;
Ly=7e-2;       % ��λΪm;
Lx=7e-2;
swx=8e3;%for full
swy=64e3;
Texc_y=4e-3;   % ��λΪs
% Texc_x=3.00e-3;
Texc_x=4e-3;
Gexc_x=-(swx/(4258*Lx*1.0e2))*1.0e-2;%%32k
Gexc_y=-(swy/(4258*Ly*1.0e2))*1.0e-2;
step_point=1;
acqrate=4.0e-6;
% Gacq_x=18.066e-2;%%for partial decdoing
Gacq_x=8.38815e-2;%for full decoding
Gacq_pe=2.236839654e-2;
[Gror,max_epiro]=calc_grad(epiro_base,Gacq_x,-0.506);
[Gped,max_epipe]=calc_grad(epipe_base,Gacq_pe,-0.508);
% Gacq_y=Gacq_y*MAX_PE/32767;
%%
%%%%%%%%%%%%%%%%���������ݶ�%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gainx=1.0;
gainy=1.0;
Gacq_x=Gacq_x*gainx;
Gacq_pe=Gacq_pe*gainy;
%%%%%%%%%%%%%%%%%%%%%%%%���ݶ��ļ�ת��Ϊʵ�ʵ����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%���ݽ���%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[numy numx]=size(st);
[FID]=lshift2r(st);
line=D2line(FID);
[FID1]=imshowxy(line,numx,1);
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��ý����λ��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
signy=1;
signx=1;
[sx_all,Lx_real]=trace_shim(epiro,Gexc_x,Texc_x,Lx,Gacq_x,acqrate,Gror,signx,2);
[sy_all,Ly_real]=trace_shim(epipe,Gexc_y,Texc_y,Ly,Gacq_pe,acqrate,Gped,signy,1);
%%
sxx=sx_all(1+2*numxx:end);
syy=sy_all(1+2*numxx:end);
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
left=0;
right=0;
odd_shift=0;
even_shift=2;
[sx,postionx]=pos_cut2(sxx,numxx,numx,numy,left,right,odd_shift,even_shift);
[sy,postiony]=pos_cut2(syy,numxx,numx,numy,left,right,odd_shift,even_shift);
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��ȡ����λ���ݶȺ�����%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% nth_start=1;
% nth_end=19;
% line=line((nth_start-1)*numx+1:nth_end*numx,1);
% sx=sx((nth_start-1)*numx+1:nth_end*numx,1);
% sy=sy((nth_start-1)*numx+1:nth_end*numx,1);
% %%
% FID=FID(nth_start:nth_end,:);
% postionx=postionx(nth_start:nth_end,:);
% postiony=postiony(nth_start:nth_end,:);
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%cut%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%ȥ��������λ%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
grid_phase=0;
if grid_phase==1
L=zeros(numy,numx);
for y=1:numy
    current=FID(y,:);
    [lx]=depha_pos(current,Gexc_x,Texc_x,Lx,y,postionx,timex,-1,'x');
%     [lx]=depha_pos2(current,Gexc_x,Texc_x,Lx,y,postionx,0,timex,1,'x');
%    [ly]=depha_pos(st,Gexc,Texc,L,posth,pos,gim,time,sign,flag)
    L(y,:)=lx;
end

figure(3)
imshow(angle(L),[],'InitialMagnification','fit');
LL=zeros(numy,numx);
for x=1:numx
    current=L(:,x);
    [ly]=depha_pos(current,Gexc_y,Texc_y,Ly,x,postiony,timey,1,'y');
%     [ly]=depha_pos2(current,Gexc_y,Texc_y,Ly,x,postiony,0,timey,1,'y');
    LL(:,x)=ly;
end
% xnum=256;
% ynum=256;
% [re,im]=grid_spiral1(postionx,postiony,LL,xnum,ynum,Lx,Ly,'cubic',1);
L_re=real(LL);
L_im=imag(LL);
FID_re=imresize(L_re,[numy*4,numx*4],'cubic');
FID_im=imresize(L_im,[numy*4,numx*4],'cubic');
FID=FID_re+1j*FID_im;
else
%%
[lxy]=smooth_phase_trace(line,sx,sy,Gexc_x,Texc_x,Lx,Gexc_y,Texc_y,Ly,0,0,gama,1);
xnum=256;
ynum=256;
[re,im]=grid_spiral1(sx,sy,lxy,xnum,ynum,Lx,Ly,'cubic',1);
FID=re+im*1j;
end
figure(3)
imshow(angle(FID),[],'InitialMagnification','fit');
%%%%%%%%%%%%%%%%%%%%%%%%%%�ؽ�����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if recon==1
tolerancex=400;
tolerancey=400;
[ynum xnum]=size(FID);
dx=Lx/(xnum-1);
dy=Ly/(ynum-1);
[numbery_inter numberx_inter]=size(FID);
numberx=xnum;
numbery=ynum;%%goal
factor=128;
grid_numx=numberx*factor;
grid_numy=numbery*factor;
xx_step=Lx/grid_numx;
yy_step=Ly/grid_numy;
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
P_martixy=zeros(numbery_inter,numbery);
for y=1:numbery_inter
    current_y=-Ly/2+dy*(y-1);
     for y_pos=1:numbery
        tempy_cos=0;
        tempy_sin=0;
        avey_number=0;
        for yy=-factor/2:factor/2
            current_yy=-Ly/2+((y_pos-1)*factor+yy)*yy_step;
            if current_yy<=Ly/2 && current_yy>=-Ly/2
                avey_number=avey_number+1;
                theta=(gama*(Gexc_y)*Texc_y/(Ly*timey))*(current_yy-current_y).^2;
                tempy_cos=tempy_cos+cos(theta);
                tempy_sin=tempy_sin+sin(theta);
            end
        end
        tempy_cos=tempy_cos/avey_number;
        tempy_sin=tempy_sin/avey_number;
        current_py=(tempy_cos+tempy_sin*1j);
%         current_py=(tempy_cos+tempy_sin*1j)*exp(-((current_yy-current_y)/Ly*80)^2/tolerancey);
        P_martixy(y,y_pos)=current_py;
    end
end
% [U,S,V]=svd(P_martixy);
% E=eye(size(P_martixy));
% P_martixy=U*E*V';
roux=zeros(numbery,numberx_inter);
for x=1:numberx_inter
    current=FID(:,x);
    current_rou=P_martixy'*current;
    roux(:,x)=current_rou;
end
figure(4)
imshow(abs(roux),[],'InitialMagnification','fit');
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
P_martixx=zeros(numberx_inter,numberx);
for x=1:numberx_inter
    current_x=-Lx/2+dx*(x-1);
    for x_pos=1:numberx
        tempx_cos=0;
        tempx_sin=0;
        avex_number=0;
        for xx=-factor/2:factor/2
            current_xx=-Lx/2+((x_pos-1)*factor+xx)*xx_step;
            if current_xx<=Lx/2 && current_xx>=-Lx/2
                avex_number=avex_number+1;
                theta=(gama*(Gexc_x)*Texc_x/(Lx*timex))*(current_xx-current_x).^2;
                tempx_cos=tempx_cos+cos(theta);
                tempx_sin=tempx_sin+sin(theta);
            end
        end
        tempx_cos=tempx_cos/avex_number;
        tempx_sin=tempx_sin/avex_number;
        current_px=(tempx_cos+tempx_sin*1j);
%         current_px=(tempx_cos+tempx_sin*1j)*exp(-((current_xx-current_x)/Lx*80)^2/tolerancex);
        P_martixx(x,x_pos)=current_px;
    end
end
% [U,S,V]=svd(P_martixx);
% E=eye(size(P_martixx));
% P_martixx=U*E*V';
rou=zeros(numbery,numberx);
for y=1:numbery
    current_L=roux(y,:);
    current_rou=P_martixx'*current_L';
    rou(y,:)=current_rou;
end
figure(5)
imshow(abs(rou),[],'InitialMagnification','fit');
figure(6)
imshow(angle(rou),[],'InitialMagnification','fit');
data=rou;
imwrite(abs(rou)/max(abs(rou(:))),'original.tiff');
end