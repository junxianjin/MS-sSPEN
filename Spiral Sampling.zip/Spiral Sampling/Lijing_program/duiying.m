function [t_line]=duiying(t_map,posy,posx)
num=length(posy);
t_line=zeros(num,1);
for p=1:1:num
    ypos=posy(p,1);
    xpos=posx(p,1);
    t_line(p,1)=t_map(ypos,xpos);
end
clear num;

        
        