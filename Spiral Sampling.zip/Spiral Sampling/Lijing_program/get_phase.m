function [phase]=get_phase(Gacq,Tacq,Ly,number,sign)
gama=2.67e8;
y_step=Ly/number;
t_step=Tacq/number;
numy=200;
y_step_step=y_step/numy;
for x=1:number
    current_pos=sign*(-Ly/2+(x-1)*y_step);
    for y=1:numy

    current_t=t_step;
    phase(x)=gama*Gacq*current_pos*current_t;
    end
end