function [lxy]=smooth_phase_x2y2(st,sx,sy,Gexc_x,Texc_x,Tacqx,Lx,Gexc_y,Texc_y,Ly,numx,gimx2,gimy2,gama,TE,sign)
Gexc_x=abs(Gexc_x);
Gexc_y=abs(Gexc_y);
num=length(sx);
numy=round(num/numx);
lxy=zeros(num,1);
const_x=gama*(Gexc_x)*Texc_x*Lx/4;
const_y=gama*(Gexc_y)*Texc_y*Ly/8;
base_x=gama*(Gexc_x)*Texc_x/Lx;
base_y=gama*(Gexc_y)*Texc_y/(2*Ly);
for y=1:1:numy
    for x=1:1:numx
        current_x=sx((y-1)*numx+x);
        current_y=sy((y-1)*numx+x);
        current_TE=(y-1/2)*Tacqx-TE+Texc_y/2;
        current_x2=gama*gimx2*current_TE*current_x*current_x;
        current_y2=gama*gimy2*current_y*current_y*current_TE;
        ther=sign*(-const_y+const_x-base_x*current_x*current_x+base_y*current_y*current_y-pi/2-current_x2-current_y2);
        re=cos(ther);
        im=sin(ther);
        current_lzre=real(st((y-1)*numx+x))*re+imag(st((y-1)*numx+x))*im;
        current_lzim=imag(st((y-1)*numx+x))*re-real(st((y-1)*numx+x))*im;
        lxy((y-1)*numx+x)=current_lzre+1j*current_lzim;
    end
end
clear re;
clear im;
clear current_x;
clear current_y;
clear ther;
clear num;
clear const_x;
clear const_y;
clear base_x;
clear base_y;
clear current_x2;
clear current_y2;
clear current_TE;
clear current_lzre;
clear current_lzim;
    