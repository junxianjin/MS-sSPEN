function [L_FFT]=lshift(L,yshift,xshift,yth,xth,number,show)
lfft=fft2(L);
lfft=fftshift(lfft);
if show==1
figure(number);
imshow(angle(lfft),[],'InitialMagnification','fit');

% subplot(2,1,1);plot(abs(lfft(yth,:)));title('��ʾһ�е�����');
% subplot(2,1,2);plot(abs(lfft(:,xth)));title('��ʾһ�е�����');
end
lfft=circshift(lfft,[yshift,xshift]);
if show==1
figure(number+1);
subplot(2,1,1);plot(abs(lfft(yth,:)));title('��ʾһ�е�����');
subplot(2,1,2);plot(abs(lfft(:,xth)));title('��ʾһ�е�����');
end
ilfft=fftshift(lfft);
ilfft=ifft2(ilfft);
% imshow(abs(ilfft),[],'InitialMagnification','fit');
L_FFT=ilfft;
clear lfft;
clear ilfft;
