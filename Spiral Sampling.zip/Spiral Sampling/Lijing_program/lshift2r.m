function [st]=lshift2r(st)
[numy numx]=size(st);
for y=1:1:numy
    if mod(y,2)==0
        for x=1:1:numx/2
            tt=st(y,x);
            st(y,x)=st(y,numx-x+1);
            st(y,numx-x+1)=tt;
        end
    end
end
clear numy;
clear numx;
clear tt;
    