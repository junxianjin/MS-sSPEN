function [FID]=imshowxy(st,numx,xu)
number=length(st);
numy=round(number/numx);
FID=zeros(numy,numx);
for y=1:numy
    for x=1:numx
        FID(y,x)=st((y-1)*numx+x);
    end
end
for y=1:numy
    if mod(y,2)==0
        for x=1:numx/2
            tt=FID(y,x);
            FID(y,x)=FID(y,numx-x+1);
            FID(y,numx-x+1)=tt;
        end
    end
end
if xu>=1
figure(xu);
imshow(abs(FID),[],'InitialMagnification','fit');
figure(xu+1)
imshow(angle(FID),[],'InitialMagnification','fit');
end
