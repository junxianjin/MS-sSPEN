function  [lxy,flat]=dephase_all(st,sx,sy,Gexc_x,Texc_x,Tacqx,Lx,Gexc_y,Texc_y,Ly,numx,acqrate,Omega,gimx,gimy,gimxy,gimx2,gimy2,sign_sx,sign_sy,gama,TE,sign)
TE=TE+2*Tacqx;
Tacq=numx*acqrate;
if Tacqx==Tacq
    tt_start=0;
    flat='Tacqx==Tacq';
else
    tt_start=(Tacqx-Tacq-acqrate)/2;
    flat='Tacqx!=Tacq';
end
Gexcx=abs(Gexc_x);
Gexcy=abs(Gexc_y);
num=length(sx);
numy=round(num/numx);
lxy=zeros(num,1);
const_x=gama*(Gexc_x)*Texc_x*Lx/4;
const_y=gama*(Gexc_y)*Texc_y*Ly/8;
base_x=gama*(Gexcx+2*sign_sx*gimx)*Texc_x/(Lx);
base_y=gama*(Gexcy+2*gimy*sign_sy)*Texc_y/(2*Ly);
for y=1:1:numy
    for x=1:1:numx
        current_x=sx((y-1)*numx+x);
        current_y=sy((y-1)*numx+x);
        current_tt=TE+tt_start+(y-1)*Tacqx+x*acqrate;
        current_xy=gama*gimxy*current_tt*current_x*current_y;
        current_x2=gama*gimx2*current_tt*current_x*current_x;
        current_y2=gama*gimy2*current_tt*current_y*current_y;
        ther=sign*(const_x-const_y-pi/2+Omega*Texc_y/2+base_y*current_y.^2-base_x*current_x.^2-current_x2-current_y2-current_xy);
        current_st=st((y-1)*numx+x);
        lxy((y-1)*numx+x)=current_st./(exp(1j*ther));
    end
end
clear re;
clear im;
clear current_x;
clear current_y;
clear ther;
clear num;
clear const_x;
clear const_y;
clear base_x;
clear base_y;
clear current_x2;
clear current_y2;
clear current_xy;
clear current_tt;
clear current_st;
clear numy;
clear tt_start;
    
 
        
        
        
