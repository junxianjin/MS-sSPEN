function [field,rate1,position]=get_map(map2d,spacex,spacey,diffx,diffy,sign)
[numbery numberx]=size(map2d);
numx=floor(numberx/spacex);
numy=floor(numbery/spacey);
field=zeros(numy,numx);
rate1=zeros(numy,numx);
position=zeros(numy,numx);
yy=0;
for y=1:1:numbery
    if mod(y,spacey)==1
        yy=yy+1;
        xx=0;
        for x=1:1:numberx
            if mod(x,spacex)==1
                xx=xx+1;
                field(yy,xx)=map2d(y,x);
                position(yy,xx)=round(x)+1j*round(y);
                if sign==1
                   rate1(yy,xx)=get_rate(map2d,x,y,diffx,diffy);
                else
                   rate1(yy,xx)=get_rate1(map2d,x,y,diffx,diffy);
                end
            end
        end
    end
end
clear xx;
clear yy;
clear numberx;
clear numbery;
clear numx;
clear numy;
clear x;
clear y;

        
        