function [data]=D2line(FID)
[numx,numy]=size(FID);
data=zeros(numx*numy,1);
for x=1:numx
    if mod(x,2)==0
        for y=1:numy/2
            tt=FID(x,y);
            FID(x,y)=FID(x,numy-y+1);
            FID(x,numy-y+1)=tt;
        end
    end
end
for y=1:numx
    for x=1:numy
        data((y-1)*numy+x)=FID(y,x);
    end
end