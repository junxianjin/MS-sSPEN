function [data_ok]=enlarge_data(first,numy,numx)
[numy1,numx1]=size(first);
if numy1<=numy && numx1<=numx
   data_ok=zeros(numy,numx);
   for y=1:1:numy
       for x=1:1:numx
           if y<=numy1 && x<=numx1
               data_ok(y,x)=first(y,x);
           else
               continue;
           end
       end
   end
else
    data_ok=0;
end
clear numy1;
clear numx1;