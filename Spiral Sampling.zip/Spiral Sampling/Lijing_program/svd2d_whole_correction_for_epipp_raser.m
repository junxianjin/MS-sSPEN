% clear;clc;clf;
%%
% [re im pha steps]=textread('lemon_data\lemon_shim.txt');
% [re im step s stpp]=load_fid('2013_12_04\epipp\x1y1=1000Hz\phantom_epipp_raser_12864_7070_sign2=1');
% [re im step s stpp]=load_fid('2013_10_30\new\phantom_epipp_chirp_64k_4ms_chirp_32k_2ms_12864_7070_sign2=1_x1y1=1517Hz');
% [re im step s stpp]=load_fid('2013_10_31\phantom_axial90_epipp_raser_chirp_64k_4ms_chirp_32k_2ms_12864_7070_sign2=-1_noshim=0');
[re im step s stpp]=load_fid(fiddir);
epiro=load('E:\Experiment Original Data\Lijing random\����\epirro1.GRD');
epipe=load(epipedir);
epiro=epiro(:,1);
% [epiro tt]=textread('Lijing_program\grad\epirro.txt');
epipe=epipe(:,1);
% [epipe ttt yy]=textread('2013_12_04\grad_file\epirpe_0.5.txt');
%%
base_num=106;
epiro(1:base_num,1)=round(epiro(1:base_num)/2);
times=2;
[epiro]=enlarge(epiro,times);
[epipe]=enlarge(epipe,times);
%%
%%%%%%%%%%%%%%%%%%%���ݽṹ��ʼ��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
numxx=212;%%ʵ�ʲµ������ز��ĵ���
numx_cut=128;%%%%%���ս�ȡ���ź�
st1=re+im*1j;
st=st1(1+numx_cut*2:end);
%%
epiro_base=(epiro(1:numxx));
epipe_base=(epipe(1:numxx*2));
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��־����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
recon=1;
%%
%----------���űȵĵ�λΪ��Hz/T-----------------%
gama=2.675200e8;
%----------�ݶȵĵ�λΪT/m-----------------%
timey=2;
timex=1;
Ly=7e-2;       % ��λΪm;
Lx=7e-2;
% swx=36e3;%for partial
% swx=64e3;%for full
swx=32e3;%for full
swy=96e3;
Texc_y=3.00e-3;   % ��λΪs
% Texc_x=3.00e-3;
Texc_x=2e-3;
Gexc_x=-(swx/(4258*Lx*1.0e2))*1.0e-2;%%32k
% Lx=abs(64e3/(4258*Gexc_x)*1.0e-4);
Gexc_y=-(swy/(4258*Ly*1.0e2))*1.0e-2;
step_point=2;
acqrate=2.0e-6;
% Gacq_x=18.066e-2;%%for partial decdoing
swacqx=1/acqrate;
% Gacq_x=swacqx/(4258*Lx)*1.0e-2;
Gacq_x=16.7763e-2;%for full decoding
Gacq_pe=30.0037e-2;
Tacqx=numxx*acqrate;
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%����ÿ���ݶ�֮ǰ�Ĳ���ֵ%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[Gror,max_epiro]=calc_grad(epiro_base,Gacq_x,-0.006);
[Gped,max_epipe]=calc_grad(epipe_base,Gacq_pe,-0.0065);
%%
%%%%%%%%%%%%%%%%���������ݶ�%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gainx=1.0;
gainy=1.0;
Gacq_x=Gacq_x*gainx;
Gacq_pe=Gacq_pe*gainy;
numy=round(length(st)/numx_cut);
%%%%%%%%%%%%%%%%%%%%%%%%���ݶ��ļ�ת��Ϊʵ�ʵ����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%���ݽ���%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[FID_cut]=cut_FID(st,numy,numx_cut,0);
% FID_cut=FID_cut(:,39:166);
[numy numx]=size(FID_cut);
line=D2line(FID_cut);
[FID]=D2Dshift(line,numy,numx,0,0);
line=D2line(FID);
[FID1]=imshowxy(line,numx,0);
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��ý����λ��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%���㲻���ȳ����ݶ�%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

correct=1;
TE=12.616e-3;%%TE=TE1-TE2+Texc_y/2;
TE=Texc_y/2-TE+224e-6;
% fx=-1500;
% fy=1300;
% fxy=0;
% fx2=0;
% fy2=0;
Omega=0;
if correct==1
   [gimx,gimy,gimxy,gimx2,gimy2]=Hz2grad(fx,fy,fxy,fx2,fy2,Lx,Ly);
else
   [gimx,gimy,gimxy,gimx2,gimy2]=Hz2grad(0,0,0,0,0,Lx,Ly);
end
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%get_the_trace_of_x_y_in_the_shim_field%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
signy=1;
signx=1;
[sx_all,Lx_fov]=trace_shim(epiro,Gexc_x,Texc_x,Lx,Gacq_x,acqrate,Gror,signx,2);
[sy_all,Ly_fov]=trace_shim(epipe,Gexc_y,Texc_y,Ly,Gacq_pe,acqrate,Gped,signy,1);
% [sx_all,Lx_fov]=find_trace(epiro,Gexc_x,Texc_x,Lx,Gacq_x,acqrate,gimx,TE,signx,1,2);
% [sy_all,Ly_fov]=find_trace(epipe,Gexc_y,Texc_y,Ly,Gacq_pe,acqrate,gimy,TE,signy,1,1);
% sx_ol=sx_all(1+2*numx:end);
% sy_ol=sy_all(1+2*numx:end);
%%
% sign_sy=1;
% sign_sx=1;
% sign_sxy=1;
% sign_sx2=1;
% sign_sy2=1;
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�����ṹ%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%function [pos,fov]=find_trace_all(epiro,sy,Gexc,Texc,Lx,Gacq,acqrate,Omega,gimx,gimy,gimxy,gimx2,TE,signx,sign_sx,sign_sy,sign_xy,sign_xx,times)
[sxx,Lx_fov1]=find_trace_all(epiro,sy_all,Gexc_x,Texc_x,Lx,Gacq_x,Gror,acqrate,Omega,gimx,gimy,gimxy,gimx2,TE,-1,1,0,1,1,1);
[syy,Ly_fov1]=find_trace_all(epipe,sx_all,Gexc_y,Texc_y,Ly,Gacq_pe,Gped,acqrate,Omega,gimy,gimx,gimxy,gimy2,TE,1,1,0,1,-1,2);
%%
sxx=sxx(1+2*numxx:end);
syy=syy(1+2*numxx:end);
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
left=0;
right=0;
odd_shift=0;
even_shift=3;
[sx,postionx]=pos_cut2(sxx,numxx,numx,numy,left,right,odd_shift,even_shift);
[sy,postiony]=pos_cut2(syy,numxx,numx,numy,left,right,odd_shift,even_shift);
%%%%%%%%%%%%%%%%%%%%%%%%ȥ��������λ%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
grid_phase=1;
if grid_phase==1
L=zeros(numy,numx);
for y=1:numy
    current=FID1(y,:);
%     [lx]=depha_pos(current,Gexc_x,Texc_x,Lx,y,postionx,timex,1,'x');
    [lx]=depha_pos2(current,Gexc_x,Texc_x,Lx,y,postionx,gimx,timex,-1,'x');
%    [ly]=depha_pos(st,Gexc,Texc,L,posth,pos,gim,time,sign,flag)
    L(y,:)=lx;
end

% figure(3)
% imshow(angle(L),[],'InitialMagnification','fit');
LL=zeros(numy,numx);
for x=1:numx
    current=L(:,x);
%     [ly]=depha_pos(current,Gexc_y,Texc_y,Ly,x,postiony,timey,1,'y');
    [ly]=depha_pos2(current,Gexc_y,Texc_y,Ly,x,postiony,gimy,timey,1,'y');
    LL(:,x)=ly;
end
% [lxy]=D2line(LL);
xnum=SRnumber;
ynum=SRnumber;
[re,im]=grid_spiral1(postionx,postiony,LL,xnum,ynum,Lx,Ly,'cubic',1);
FID=re+im*1j;
% figure(4)
% imshow(angle(LL),[],'InitialMagnification','fit');
% L_re=real(LL);
% L_im=imag(LL);
% FID_re=imresize(L_re,[numy*4,numx*4],'cubic');
% FID_im=imresize(L_im,[numy*4,numx*4],'cubic');
% FID=FID_re+1j*FID_im;
else
%%
sign_x=1;
sign_y=1;
% [lxy]=smooth_phase_trace(line,sx,sy,Gexc_x,Texc_x,Lx,Gexc_y,Texc_y,Ly,gimx,gimy,gama,1);
[lxy,flat]=dephase_all(line,sx,sy,Gexc_x,Texc_x,Tacqx,Lx,Gexc_y,Texc_y,Ly,numx,acqrate,Omega,gimx,gimy,gimxy,gimx2,gimy2,sign_x,sign_y,gama,TE,1);
% [FID]=imshowxy(lxy,numx,3);
% %%
xnum=SRnumber;
ynum=SRnumber;
% [re,im]=grid_spiral(sx,sy,lxy,xnum,ynum,'cubic',1);
[re,im]=grid_spiral1(sx,sy,lxy,xnum,ynum,Lx,Ly,'cubic',1);
FID=re+im*1j;
end
% figure(3)
% imshow(abs(FID),[],'InitialMagnification','fit');
%%%%%%%%%%%%%%%%%%%%%%%%%%�ؽ�����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if recon==1
tolerancex=400;
tolerancey=400;
[ynum xnum]=size(FID);
dx=Lx/(xnum-1);
dy=Ly/(ynum-1);
[numbery_inter numberx_inter]=size(FID);
numberx=SRnumber;
numbery=SRnumber;%%goal
factor=120;
grid_numx=numberx*factor;
grid_numy=numbery*factor;
xx_step=Lx/grid_numx;
yy_step=Ly/grid_numy;
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
P_martixy=zeros(numbery_inter,numbery);
ygrid=linspace(-Ly/2,Ly/2,ynum);
for y=1:length(ygrid)
    current_y=ygrid(y);
     for y_pos=1:numbery
        tempy_cos=0;
        tempy_sin=0;
        avey_number=0;
        for yy=0:factor
            current_yy=-Ly/2+((y_pos-1)*factor+yy)*yy_step;
            if current_yy<=Ly/2 && current_yy>=-Ly/2
                avey_number=avey_number+1;
                theta=(gama*(Gexc_y+2*gimy)*Texc_y/(Ly*timey))*(current_yy-current_y).^2;
                tempy_cos=tempy_cos+cos(theta);
                tempy_sin=tempy_sin+sin(theta);
            end
        end
        tempy_cos=tempy_cos/avey_number;
        tempy_sin=tempy_sin/avey_number;
        current_py=(tempy_cos+tempy_sin*1j);
%         current_py=(tempy_cos+tempy_sin*1j)*exp(-((current_yy-current_y)/Ly*100)^2/tolerancey);
        P_martixy(y,y_pos)=current_py;
    end
end
% [U,S,V]=svd(P_martixy);
% E=eye(size(P_martixy));
% P_martixy=U*E*V';
roux=zeros(numbery,numberx_inter);
for x=1:numberx_inter
    current=FID(:,x);
    current_rou=P_martixy'*current;
    roux(:,x)=current_rou;
end
% figure(4)
% imshow(abs(roux),[],'InitialMagnification','fit');
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
P_martixx=zeros(numberx_inter,numberx);
xgrid=linspace(-Lx/2,Lx/2,xnum);
for x=1:length(xgrid)
    current_x=xgrid(x);
    for x_pos=1:numberx
        tempx_cos=0;
        tempx_sin=0;
        avex_number=0;
        for xx=0:factor
            current_xx=-Lx/2+((x_pos-1)*factor+xx)*xx_step;
            if current_xx<=Lx/2 && current_xx>=-Lx/2
                avex_number=avex_number+1;
                theta=(gama*(Gexc_x-2*gimx)*Texc_x/(Lx*timex))*(current_xx-current_x).^2;
                tempx_cos=tempx_cos+cos(theta);
                tempx_sin=tempx_sin+sin(theta);
            end
        end
        tempx_cos=tempx_cos/avex_number;
        tempx_sin=tempx_sin/avex_number;
        current_px=(tempx_cos+tempx_sin*1j);
%         current_px=(tempx_cos+tempx_sin*1j)*exp(-((current_xx-current_x)/Lx*100)^2/tolerancex);
        P_martixx(x,x_pos)=current_px;
    end
end
% [U,S,V]=svd(P_martixx);
% E=eye(size(P_martixx));
% % P_martixx=U*E*V';
rou=zeros(numbery,numberx);
for y=1:numbery
    current_L=roux(y,:);
    current_rou=P_martixx'*current_L';
    rou(y,:)=current_rou;
end
figure(5)
imshow(abs(rou),[],'InitialMagnification','fit');
% print('-depsc','-tiff','-r600','paper_figures\phantom30_raser2d_x1y1=700')
figure(6)
imshow(angle(rou),[],'InitialMagnification','fit');
data=rou;
% save data\phantom30_raser2d_noshim=0 data
out=0;
if out==1
fid=fopen('field_map\brain_shim_amp_shim.txt','w+');
fprintf(fid,'%e\n',abs(roux));
fclose(fid);
fid=fopen('field_map\brain_shim_pha_shim.txt','w+');
fprintf(fid,'%e\n',angle(roux));
fclose(fid);
end
% save data roux
end
