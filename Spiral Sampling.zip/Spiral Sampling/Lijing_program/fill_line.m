function [flz]=fill_line(lz,expand_num)
num=length(lz);
flz=zeros(num*expand_num,1);
re_lz=real(lz);
im_lz=imag(lz);
for x=0:1:num-2
    for y=0:1:expand_num/2-1
        current_re=((expand_num/2-y)*re_lz(x+1)+y*re_lz(x+2))/(expand_num/2);
        current_im=((expand_num/2-y)*im_lz(x+1)+y*im_lz(x+2))/(expand_num/2);
        flz(x*expand_num/2+y+1+num*expand_num/2)=current_re+1j*current_im;
    end
end
xx=num-1;
 for y=0:1:expand_num/2-1
        current_ree=lz(x+1);
        current_imm=lz(x+1);
        flz(x*expand_num/2+y+1+num*expand_num/2)=current_ree+1j*current_imm;
 end
 clear current_re;
 clear current_im;
 clear current_ree;
 clear current_imm;
 clear num;
 clear im_lz;
 clear re_lz;
