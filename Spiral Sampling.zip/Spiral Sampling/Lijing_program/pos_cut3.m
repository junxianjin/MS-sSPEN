function [sx,postion]=pos_cut3(sx,numxx,numx,numy,left,right,odd_shift,even_shift)
if numxx==numx
    [postion]=D2Dshift(sx,numy,numx,left,right);
    sx=D2line(postion);

else
number=length(sx);
if number==numxx*numy
    [SX]=cut_FID(sx,numy,numxx,0);
    line=D2line(SX);
    [pos]=D2Dshift(line,numy,numxx,left,right);
    pos_odd=zeros(numy/2,numxx);
    pos_even=zeros(numy/2,numxx);
    mm=0;nn=0;
    for y=1:1:numy
        if mod(y,2)==1
            mm=mm+1;
            pos_odd(mm,:)=pos(y,:);
        else
            nn=nn+1;
            pos_even(nn,:)=pos(y,:);
        end
    end
            
    cut=numxx-numx;
    cut=round(cut/2);
    cut1=cut+odd_shift;
    cut2=cut+even_shift;
    pos_odd=pos_odd(:,cut1:cut1+numx-1);
    pos_even=pos_even(:,cut2:cut2+numx-1);
    postion=zeros(numy,numx);
    mm=0;nn=0;
    for y=1:1:numy
        if mod(y,2)==1
            mm=mm+1;
            postion(y,:)=pos_odd(mm,:);
        else
            nn=nn+1;
            postion(y,:)=pos_even(nn,:);
        end
    end
            
    sx=D2line(postion);
else
    sx=0;
end
end
clear number;
clear line;
clear SX;
clear cut;
clear pos1;
clear pos;
