function [ly]=depha_pos2(st,Gexc,Texc,L,posth,pos,gim,time,sign,flag)
Gexc=abs(Gexc);
gama=2.6752e8;
num=length(st);
ly=zeros(num,1);
if flag=='x'
    current_pos1d=pos(posth,:);
    const1=-gama*(Gexc)*Texc*L/4;
    base=gama*(Gexc+2*gim)*Texc/(time*L);
end
if flag=='y'
    current_pos1d=pos(:,posth);
    const1=gama*(Gexc)*Texc*L/8-pi/2;
    base=gama*(Gexc+2*gim)*Texc/(time*L);
end

for x=1:num
    current_pos=current_pos1d(x);
    ther=sign*(-const1+base*current_pos*current_pos);
    re=cos(ther);
    im=sin(ther);
%     current_lzre=real(st(num-x+1))*re+imag(st(num-x+1))*im;
%     current_lzim=imag(st(num-x+1))*re-real(st(num-x+1))*im;
    current_lzre=real(st(x))*re+imag(st(x))*im;
    current_lzim=imag(st(x))*re-real(st(x))*im;
    ly(x)=current_lzre+1j*current_lzim;
end
clear num;
clear step;
clear ther;
clear re;
clear im;
clear current_lzre;
clear current_lzim;