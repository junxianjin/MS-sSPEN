function [map,pos]=map_chose(field,rate1,position,adu,base)
[numy numx]=size(field);
map=zeros(numy*numx,1);
pos=zeros(numy*numx,1);
max_rate=max(max(abs(rate1)));
if adu==0
    base_rate=base;
else
    base_rate=adu*max_rate;
end
nth=0;
for y=1:1:numy
    for x=1:1:numx
        current_field=field(y,x);
        current_rate=abs(rate1(y,x));
        if current_field~=0 && current_rate<base_rate
            nth=nth+1;
            map(nth,1)=current_field;
            pos(nth,1)=position(y,x);
        end
    end
end
clear numy;
clear numx;
clear max_rate;
clear base_rate;
clear nth;