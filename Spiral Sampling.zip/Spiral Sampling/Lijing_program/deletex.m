function [FID]=deletex(FID1,sign)
[numy numx]=size(FID1);
FID=zeros(round(numy/2),numx);
if sign==1
    n=0;
   for y=1:1:numy
       if mod(y,2)==1
           n=n+1;
           FID(n,:)=FID1(y,:);
       end
   end
end
if sign==2
    n=0;
   for y=1:1:numy
       if mod(y,2)==0
           n=n+1;
           FID(n,:)=FID1(y,:);
       end
   end
end


           
