function [position_y]=cut_pos(pos,numx,sign)
number=length(pos);
poss=zeros(round(number/2),1);
if sign==1
    n=0;
    for x=1:number
        if mod(x,2)==1
            n=n+1;
            poss(n)=pos(x);
        end
    end
end
if sign==2
    n=0;
    for x=1:number
        if mod(x,2)==0
            n=n+1;
            poss(n)=pos(x);
        end
    end
end
position_y=poss;

