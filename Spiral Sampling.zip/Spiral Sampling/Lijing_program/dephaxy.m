function [lxy]=dephaxy(st,sx,sy,Gexc_x,Texc_x,Lx,Gexc_y,Texc_y,Ly,gama,sign)
num=length(sx);
lxy=zeros(num,1);
for x=1:num
    current_x=sx(x);
    current_y=sy(x);
    ther=sign*gama*((Lx/4-current_x.^2/Lx)*Gexc_x*Texc_x+(current_y.^2/(2*Ly)-Ly/8)*Gexc_y*Texc_y);
    re=cos(ther);
    im=sin(ther);
    current_lzre=real(st(x))*re+imag(st(x))*im;
    current_lzim=imag(st(x))*re-real(st(x))*im;
    lxy(x)=current_lzre+1j*current_lzim;
end
clear re;
clear im;
clear current_x;
clear current_y;
clear ther;
clear num;
    