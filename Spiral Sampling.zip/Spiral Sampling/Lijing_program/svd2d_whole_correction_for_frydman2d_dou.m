% clear;clc;clf;
%%
% [re im pha steps]=textread('lemon_data\lemon_shim.txt');
% [re im step s stpp]=load_fid('2013_10_30\new\phantom_epipp_raser_12864_7070_sign2=-1');
[re im step s stpp]=load_fid(fiddir);
% [epiro tt]=textread('grad\epiro.txt');
% [epipe ttt]=textread('grad\epipe.txt');
epiro=load('Lijing_program\grad\epiro.GRD');
epipe=load(epipedir);
epiro=epiro(:,1);
epipe=epipe(:,1);


%%
base_num=100;
epiro(1:base_num,1)=round(epiro(1:base_num)/2);
times=2;
[epiro]=enlarge(epiro,times);
[epipe]=enlarge(epipe,times);
%%
%%%%%%%%%%%%%%%%%%%���ݽṹ��ʼ��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
numxx=200;%%ʵ�ʲɵ������ز��ĵ���
numx_cut=128;%%%%%���ս�ȡ���ź�
%%
re=re';im=im';
st=re+1j*im;
[numy,numxst]=size(st);
st=st(numy/2+1:end,:);
%%
%%
epiro_base=(epiro(1:numxx));
epipe_base=(epipe(1:end));
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��־����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
recon=1;
%%
%----------���űȵĵ�λΪ��Hz/T-----------------%
gama=2.675200e8;
%----------�ݶȵĵ�λΪT/m-----------------%
timey=2;
timex=1;
Ly=7e-2;       % ��λΪm;
Lx=7e-2;
% swx=36e3;%for partial
% swx=64e3;%for full
swx=32e3;%for full
swy=64e3;
Texc_y=3.00e-3;   % ��λΪs
% Texc_x=3.00e-3;
Texc_x=2e-3;
Gexc_x=-(swx/(4258*Lx*1.0e2))*1.0e-2;%%32k
% Lx=abs(64e3/(4258*Gexc_x)*1.0e-4);
Gexc_y=-(swy/(4258*Ly*1.0e2))*1.0e-2;
step_point=2;
acqrate=2.0e-6;
% Gacq_x=18.066e-2;%%for partial decdoing
Gacq_x=16.7763e-2;%for full decoding
Gacq_pe=1.6776297405e-2*adu_random;
Tacqx=numxx*acqrate;
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%����ÿ���ݶ�֮ǰ�Ĳ���ֵ%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[Gror,max_epiro]=calc_grad(epiro_base,Gacq_x,-0.006);
% [Gped,max_epipe]=calc_grad(epipe_base,Gacq_pe,-0.5075);
[Gped,max_epipe]=calc_grad(epipe_base,Gacq_pe,-0.5075);
%%
%%%%%%%%%%%%%%%%���������ݶ�%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gainx=1.0;
gainy=1.0;
Gacq_x=Gacq_x*gainx;
Gacq_pe=Gacq_pe*gainy;
%%%%%%%%%%%%%%%%%%%%%%%%���ݶ��ļ�ת��Ϊʵ�ʵ����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%���ݽ���%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[numy numx]=size(st);
[FID]=lshift2r(st);
line=D2line(FID);
[FID1]=imshowxy(line,numx,1);
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%��ý����λ��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%���㲻���ȳ����ݶ�%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

correct=0;
TE=11.592e-3;%%TE=TE1-TE2+Texc_y/2;
TE=Texc_y/2-TE+224e-6;
fx=-700;
fy=500;
fxy=160;
fx2=400;
fy2=400;
Omega=0;
if correct==1
   [gimx,gimy,gimxy,gimx2,gimy2]=Hz2grad(fx,fy,fxy,fx2,fy2,Lx,Ly);
else
   [gimx,gimy,gimxy,gimx2,gimy2]=Hz2grad(0,0,0,0,0,Lx,Ly);
end
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%get_the_trace_of_x_y_in_the_shim_field%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
signy=1;
signx=1;
[sx_all,Lx_fov]=trace_shim(epiro,Gexc_x,Texc_x,Lx,Gacq_x,acqrate,Gror,signx,2);
[sy_all,Ly_fov]=trace_shim(epipe,Gexc_y,Texc_y,Ly,Gacq_pe,acqrate,Gped,signy,1);
% [sx_all,Lx_fov]=find_trace(epiro,Gexc_x,Texc_x,Lx,Gacq_x,acqrate,gimx,TE,signx,1,2);
% [sy_all,Ly_fov]=find_trace(epipe,Gexc_y,Texc_y,Ly,Gacq_pe,acqrate,gimy,TE,signy,1,1);
% sx_ol=sx_all(1+2*numx:end);
% sy_ol=sy_all(1+2*numx:end);
%%
% sign_sy=1;
% sign_sx=1;
% sign_sxy=1;
% sign_sx2=1;
% sign_sy2=1;
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�����ṹ%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%function [pos,fov]=find_trace_all(epiro,sy,Gexc,Texc,Lx,Gacq,acqrate,Omega,gimx,gimy,gimxy,gimx2,TE,signx,sign_sx,sign_sy,sign_xy,sign_xx,times)
[sxx,Lx_fov1]=find_trace_all(epiro,sy_all,Gexc_x,Texc_x,Lx,Gacq_x,Gror,acqrate,Omega,gimx,gimy,gimxy,gimx2,TE,-1,1,0,1,1,1);
[syy,Ly_fov1]=find_trace_all(epipe,sx_all,Gexc_y,Texc_y,Ly,Gacq_pe,Gped,acqrate,Omega,gimy,gimx,gimxy,gimy2,TE,1,1,0,1,-1,2);
%%
sxx=sxx(1+2*numxx:end);
syy=syy(1+2*numxx:end);
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
left=0;
right=0;
odd_shift=0;
even_shift=3;
[sx,postionx]=pos_cut2(sxx,numxx,numx,numy,left,right,odd_shift,even_shift);
[sy,postiony]=pos_cut2(syy,numxx,numx,numy,left,right,odd_shift,even_shift);
%%%%%%%%%%%%%%%%%%%%%%%%ȥ��������λ%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
grid_phase=1;
if grid_phase==1
L=zeros(numy,numx);
for y=1:numy
    current=FID1(y,:);
%     [lx]=depha_pos(current,Gexc_x,Texc_x,Lx,y,postionx,timex,1,'x');
    [lx]=depha_pos2(current,Gexc_x,Texc_x,Lx,y,postionx,gimx,timex,-1,'x');
%    [ly]=depha_pos(st,Gexc,Texc,L,posth,pos,gim,time,sign,flag)
    L(y,:)=lx;
end

figure(3)
imshow(angle(L),[],'InitialMagnification','fit');
LL=zeros(numy,numx);
for x=1:numx
    current=L(:,x);
%     [ly]=depha_pos(current,Gexc_y,Texc_y,Ly,x,postiony,timey,1,'y');
    [ly]=depha_pos2(current,Gexc_y,Texc_y,Ly,x,postiony,gimy,timey,1,'y');
    LL(:,x)=ly;
end
% [lxy]=D2line(LL);
xnum=128;
ynum=xnum;
[re,im]=grid_spiral1(postionx,postiony,LL,xnum,ynum,Lx,Ly,'cubic',1);
FID=re+im*1j;
% figure(4)
% imshow(angle(LL),[],'InitialMagnification','fit');
% L_re=real(LL);
% L_im=imag(LL);
% FID_re=imresize(L_re,[numy*4,numx*4],'cubic');
% FID_im=imresize(L_im,[numy*4,numx*4],'cubic');
% FID=FID_re+1j*FID_im;
else
%%
sign_x=1;
sign_y=1;
[lxy]=smooth_phase_trace(line,sx,sy,Gexc_x,Texc_x,Lx,Gexc_y,Texc_y,Ly,gimx,gimy,gama,1);
% [lxy,flat]=dephase_all(line,sx,sy,Gexc_x,Texc_x,Tacqx,Lx,Gexc_y,Texc_y,Ly,numx,acqrate,Omega,gimx,gimy,gimxy,gimx2,gimy2,sign_x,sign_y,gama,TE,1);
% [FID]=imshowxy(lxy,numx,3);
% %%
xnum=256;
ynum=256;
% [re,im]=grid_spiral(sx,sy,lxy,xnum,ynum,'cubic',1);
[re,im]=grid_spiral1(sx,sy,lxy,xnum,ynum,Lx,Ly,'cubic',1);
FID=re+im*1j;
end
figure(3)
imshow(abs(FID),[],'InitialMagnification','fit');
%%%%%%%%%%%%%%%%%%%%%%%%%%�ؽ�����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if recon==1
tolerancex=400;
tolerancey=400;
[ynum xnum]=size(FID);
dx=Lx/(xnum-1);
dy=Ly/(ynum-1);
[numbery_inter numberx_inter]=size(FID);
numberx=128;
numbery=numberx;%%goal
factor=128;
grid_numx=numberx*factor;
grid_numy=numbery*factor;
xx_step=Lx/grid_numx;
yy_step=Ly/grid_numy;
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
P_martixy=zeros(numbery_inter,numbery);
for y=1:numbery_inter
    current_y=-Ly/2+dy*(y-1);
     for y_pos=1:numbery
        tempy_cos=0;
        tempy_sin=0;
        avey_number=0;
        for yy=-factor/2:factor/2
            current_yy=-Ly/2+((y_pos-1)*factor+yy)*yy_step;
            if current_yy<=Ly/2 && current_yy>=-Ly/2
                avey_number=avey_number+1;
                theta=(gama*(Gexc_y+2*gimy)*Texc_y/(Ly*timey))*(current_yy-current_y).^2;
                tempy_cos=tempy_cos+cos(theta);
                tempy_sin=tempy_sin+sin(theta);
            end
        end
        tempy_cos=tempy_cos/avey_number;
        tempy_sin=tempy_sin/avey_number;
        current_py=(tempy_cos+tempy_sin*1j);
%         current_py=(tempy_cos+tempy_sin*1j)*exp(-((current_yy-current_y)/Ly*100)^2/tolerancey);
        P_martixy(y,y_pos)=current_py;
    end
end
% [U,S,V]=svd(P_martixy);
% E=eye(size(P_martixy));
% P_martixy=U*E*V';
roux=zeros(numbery,numberx_inter);
for x=1:numberx_inter
    current=FID(:,x);
    current_rou=P_martixy'*current;
    roux(:,x)=current_rou;
end
figure(4)
imshow(abs(roux),[],'InitialMagnification','fit');
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
P_martixx=zeros(numberx_inter,numberx);
for x=1:numberx_inter
    current_x=-Lx/2+dx*(x-1);
    for x_pos=1:numberx
        tempx_cos=0;
        tempx_sin=0;
        avex_number=0;
        for xx=-factor/2:factor/2
            current_xx=-Lx/2+((x_pos-1)*factor+xx)*xx_step;
            if current_xx<=Lx/2 && current_xx>=-Lx/2
                avex_number=avex_number+1;
                theta=(gama*(Gexc_x-2*gimx)*Texc_x/(Lx*timex))*(current_xx-current_x).^2;
                tempx_cos=tempx_cos+cos(theta);
                tempx_sin=tempx_sin+sin(theta);
            end
        end
        tempx_cos=tempx_cos/avex_number;
        tempx_sin=tempx_sin/avex_number;
        current_px=(tempx_cos+tempx_sin*1j);
%         current_px=(tempx_cos+tempx_sin*1j)*exp(-((current_xx-current_x)/Lx*100)^2/tolerancex);
        P_martixx(x,x_pos)=current_px;
    end
end
% [U,S,V]=svd(P_martixx);
% E=eye(size(P_martixx));
% % P_martixx=U*E*V';
rou=zeros(numbery,numberx);
for y=1:numbery
    current_L=roux(y,:);
    current_rou=P_martixx'*current_L';
    rou(y,:)=current_rou;
end
figure(5)
imshow(abs(rou),[],'InitialMagnification','fit');
% print('-depsc','-tiff','-r600','paper_figures\brain_shim')
figure(6)
imshow(angle(rou),[],'InitialMagnification','fit');
roh=imresize(abs(rou),[256 256]);
imwrite(roh/(1.2*max(roh(:))),'original.tiff');
% data=rou;
% save raser2d data
out=0;

if out==1
fid=fopen('field_map\brain_shim_amp_shim.txt','w+');
fprintf(fid,'%e\n',abs(roux));
fclose(fid);
fid=fopen('field_map\brain_shim_pha_shim.txt','w+');
fprintf(fid,'%e\n',angle(roux));
fclose(fid);
end
% save data roux
end
