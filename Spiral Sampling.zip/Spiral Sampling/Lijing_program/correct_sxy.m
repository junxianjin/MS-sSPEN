function [sxx]=correct_sxy(sx,Gexc,Texc,L,acqrate,gim,TE,sign)
gama=2.675200e8;
number=length(sx);
format long;
pos_inh=zeros(number,1);
for x=1:1:number
    format long;
    current_t=x*acqrate;
    pos_inh(x)=gama*gim*current_t;
end
base_inh=gama*gim*TE;
base=2*gama*(Gexc+gim)*Texc;
sxx=sx+sign*L*(base_inh-pos_inh)./(base);
clear number;
clear pos_inh;
clear current_t;
clear base_inh;
clear base;

