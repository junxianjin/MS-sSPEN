% ��ά�ռ���봦������
% by ľľ 2013��3��15��11:06:15
ini;
addpath(strcat(pwd,'/myCS'));
addpath(strcat(pwd,'/utils'));
addpath(strcat(pwd,'/rwt-master'));
Shapelib_mat_dir = 'E:\Experiment Original Data\Spiral sampling\Shapelib\Mat\';
gama=2.6752e8;
%-----------------------------------------
%==================ʱ���=================
%-----------------------------------------
date_now=datestr(now);
date_hour=num2str(hour(date_now));
date_minute=num2str(minute(date_now));
date_second=num2str(second(date_now));
time=['_',date_hour,'_',date_minute,'_',date_second];

%%
%-----------------------------------------
%==================��������=================
%-----------------------------------------
param.Spiral = 1; % �ж��Ƿ������������ǵȼ��   0�ȼ��  1����
param.CS=0;
param.De_con=1;
param.correct=0;% ������λУ��
param.imshow = 0;
param.savedate=1;
param.simu=0;
param.iteration=8;
param.num=256;
Smax=80;
%%
%------------------------------------%
%----------------��������------------%
%------------------------------------%
if param.simu==0
    param.datadir='E:\Achievement\Journal Article\3 Non-Cartesian for SPEN MRI\Data\OrginalData\LemonData\SPENSpiral_64k3ms_6k6ms_Ga_14_Smax_60_FOV_60_6996.fid';
    [RE,IM,NP,NB,NT,HDR]=load_fid(param.datadir,1);
    param.st=RE+1i*IM;
    Para=getpar(param.datadir,'p1_bw','pw1','lpe','pepat','gradpe','pp_bw','pp','lro','ropat','gradro');
    PE.L = Para.lpe*1e-2;
    PE.sw = Para.p1_bw;
    PE.Te = Para.pw1;
    PE.Ga = Para.gradpe*1e-2;
    PE.pepat = Para.pepat;
    PE.Ge=-PE.sw/(gama*PE.L)*2*pi;
    PE.chirp=1; % 1����90�� 2����180��
    
    RO.L = Para.lro*1e-2;
    RO.sw = Para.pp_bw;
    RO.Te = Para.pp;
    RO.Ga = Para.gradro*1e-2;
    RO.pepat = Para.ropat;
    RO.Ge = RO.sw/(gama*RO.L)*2*pi;
    RO.chirp=2;
    
    load([Shapelib_mat_dir,PE.pepat]);
    load([Shapelib_mat_dir,RO.pepat]);
    
    temp = 1;
    while(PE_Gsam(temp)==0 && RO_Gsam(temp)==0)
        temp = temp+1;
    end
    
    PE.Gsam = PE_Gsam(temp:end);
    RO.Gsam = RO_Gsam(temp:end);
    param.st = param.st(temp:end);

    param.datadir=[param.datadir,'\'];
    
else 
    param.datadir='E:\Experiment Original Data\Spiral sampling\Simulation\05-Sep-2015_DemonstrationDifferentTrajectory_paper\SquareSpiral64k3ms_32k3ms_Lx45mm_Ly45mm_sampts_7094_Gmax_20_Smax_80_21_12_34';
    param.datadir=[param.datadir,'\'];
    name='temp_SpiralPhantom_new';
    temp=dir([param.datadir,'param.mat']);
    temp=struct2cell(temp)';
    load([param.datadir,temp{1}]);  % ��������
    param.st=readtempccb2D([param.datadir,name,'.ccb'],PE,RO);   % ��������

end

if param.savedate==1
    savedatadir=[param.datadir,'\',date,'_',date_hour,'_',date_minute,'_',date_second];
    mkdir(savedatadir);
    copyfile([mfilename,'.m'],[savedatadir,'\']);
    param.savedatadir=savedatadir;
end
figure;
plot(abs(param.st));title(num2str(length(param.st)))

% param.st(1:param.cut(1)) = 0;
% param.st(param.cut(2):end) = 0;

if param.simu==1
    PE.Ge = -PE.Ge;
    RO.Ge = -RO.Ge;
    RO.Ga = RO.Ga;
    PE.Ga = PE.Ga;
else
    PE.Ge = -PE.Ge;
    RO.Ge = RO.Ge;
    factor_x=-Smax*1e-3*0.5;
    factor_y=-Smax*1e-3*0.8;
    PE.phasefactor=1+factor_y;
    RO.phasefactor=1-factor_x;
end
param.gama=gama;
PE_bk=PE;
RO_bk=RO;
param_bk=param;
%%
%------------------------------------%
%----------------�����ؽ�------------%
%------------------------------------%
if param.De_con==1
    param = param_bk;
    PE = PE_bk;
    RO = RO_bk;
    SPEN2D_calPmatrix
    Pr=Pmatrix2d(PE.P_matrix,RO.P_matrix);
    roh=Pr'*param.st;
    param.method='De-con';
    postprocess_2D_SPEN(roh,PE,RO,param)
end


if param.CS==1
    param = param_bk;
    PE = PE_bk;
    RO = RO_bk;
    SPEN2D_calPmatrix
    xfmWeight = 2e-3;
    TVWeight = 1e-3;
    Itnlim=8;
    XFM = Wavelet('Daubechies',6,1);
%     XFM = TIDCT(6,4);
%     XFM = 1;
    myCS_2D
    param.method='CS';
    postprocess_2D_SPEN(roh,PE,RO,param)
end


